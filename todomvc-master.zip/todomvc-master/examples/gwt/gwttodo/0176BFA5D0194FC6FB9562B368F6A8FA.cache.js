(function(){var $gwt_version = "2.6.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $strongName = '0176BFA5D0194FC6FB9562B368F6A8FA';var $stats = $wnd.__gwtStatsEvent ? function(a) {return $wnd.__gwtStatsEvent(a);} : null;var $sessionId = $wnd.__gwtStatsSessionId ? $wnd.__gwtStatsSessionId : null;$stats && $stats({moduleName:'gwttodo',sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date()).getTime(),type:'moduleEvalStart'});function V(){}
function LE(){}
function ab(){}
function ag(){}
function Sg(){}
function Sc(){}
function vc(){}
function Mc(){}
function ke(){}
function Ke(){}
function $e(){}
function $n(){}
function Xn(){}
function hf(){}
function Jh(){}
function Jr(){}
function Aq(){}
function Dq(){}
function Ks(){}
function qt(){}
function tt(){}
function tu(){}
function qu(){}
function Eu(){}
function Ov(){}
function Lw(){}
function Sx(){}
function Vx(){}
function Yx(){}
function ty(){}
function wy(){}
function ez(){}
function pD(){}
function vw(a){}
function vb(){Kc()}
function Fr(){Er()}
function ks(){js()}
function Vs(a){Ms=a}
function Ce(a,b){a.i=b}
function Ee(a,b){a.a=b}
function Fe(a,b){a.b=b}
function lx(a,b){a.b=b}
function kx(a,b){a.a=b}
function Hm(a,b){a.h=b}
function Im(a,b){a.l=b}
function Jm(a,b){a.m=b}
function po(a,b){a.u=b}
function Qc(a,b){a.a+=b}
function Rc(a,b){a.a+=b}
function gd(b,a){b.id=a}
function jb(a){this.a=a}
function Bc(a){this.a=a}
function Ec(a){this.a=a}
function pf(a){this.a=a}
function Rf(a){this.a=a}
function wg(a){this.a=a}
function Hg(a){this.a=a}
function Xg(a){this.a=a}
function jh(a){this.a=a}
function bo(a){this.a=a}
function sp(a){this.a=a}
function Cp(a){this.a=a}
function Ep(a){this.a=a}
function dq(a){this.a=a}
function vq(a){this.a=a}
function fr(a){this.a=a}
function ys(a){this.a=a}
function sw(a){this.a=a}
function sv(a){this.c=a}
function Cx(a){this.a=a}
function Ex(a){this.a=a}
function Gx(a){this.a=a}
function Ix(a){this.a=a}
function ky(a){this.a=a}
function ny(a){this.a=a}
function $y(a){this.a=a}
function rz(a){this.a=a}
function Ez(a){this.a=a}
function sB(a){this.a=a}
function JB(a){this.a=a}
function FC(a){this.a=a}
function jC(a){this.d=a}
function vD(a){this.b=a}
function GD(a){this.b=a}
function ef(){this.a={}}
function vg(){this.a=[]}
function AA(){yA(this)}
function oE(){ZA(this)}
function pE(){ZA(this)}
function fb(){new UC}
function fc(){return bc}
function Cg(a){return a.a}
function Lg(a){return a.a}
function Vg(){return null}
function ah(a){return a.a}
function ph(a){return a.a}
function wh(){return null}
function Ih(a){return a.a}
function ad(a){a.focus()}
function yA(a){a.a=new Sc}
function db(){db=LE;new fb}
function me(){me=LE;oe()}
function Ut(){Ut=LE;xv()}
function $t(){$t=LE;du()}
function Pu(){Pu=LE;Xu()}
function lb(){this.a=mb()}
function Te(){this.c=++Qe}
function Du(){throw new JE}
function Kw(a){Rv(a.a,a.b)}
function Nn(a,b){Tn(a.a,b)}
function Bx(a,b){ux(a.a,b)}
function bp(a,b){Wq(a.n,b)}
function Vt(a,b){Ot(a.b,b)}
function cy(a,b){Bv(b,a.n)}
function jd(c,a,b){c[a]=b}
function Fd(c,a,b){c[a]=b}
function df(a,b,c){a.a[b]=c}
function Nb(b,a){b.length=a}
function _b(a){!!a&&ts(a.a)}
function wc(a){return a.C()}
function Lf(){Mf.call(this)}
function Of(){Mf.call(this)}
function Vy(){vb.call(this)}
function nz(){vb.call(this)}
function yz(){vb.call(this)}
function Bz(){vb.call(this)}
function Rz(){vb.call(this)}
function EA(){vb.call(this)}
function JE(){vb.call(this)}
function uE(){this.a=new oE}
function vE(){this.a=new pE}
function vA(){this.a=new Sc}
function Uf(){this.a=new Lf}
function rn(){this.a=new AA}
function wb(a){this.e=a;Kc()}
function xb(a){this.e=a;Kc()}
function hv(a,b){kv(a,b,a.c)}
function Xo(a,b){kp(a,a.c,b)}
function Hy(a,b){rx(b.a,a.a)}
function Oy(a,b){sx(b.a,a.a)}
function Dy(a){Cy();this.a=a}
function Td(){Rd();return Md}
function lg(){jg();return fg}
function tr(){rr();return nr}
function Br(){zr();return vr}
function Zu(){Xu();return Su}
function Qx(){Ox();return Kx}
function Rr(){Rr=LE;Pr=new Ks}
function Er(){Er=LE;Dr=new Te}
function js(){js=LE;is=new Te}
function Ab(){Ab=LE;zb=new V}
function Fq(){Fq=LE;zq=new Dq}
function mc(){mc=LE;lc=new vc}
function Rg(){Rg=LE;Qg=new Sg}
function xy(){xy=LE;sy=new wy}
function Cy(){Cy=LE;By=new Uf}
function lD(){lD=LE;kD=new pD}
function eE(){this.a=new Date}
function en(){return !!$stats}
function cf(a,b){return a.a[b]}
function kd(b,a){b.tabIndex=a}
function Ed(b,a){b.checked=a}
function fd(b,a){b.className=a}
function Kb(b,a){b[b.length]=a}
function Lb(b,a){b[b.length]=a}
function Mb(b,a){b[b.length]=a}
function Ng(a){wb.call(this,a)}
function Og(a){yb.call(this,a)}
function Bt(a){yt.call(this,a)}
function $f(a){Xf.call(this,a)}
function Hp(a){pf.call(this,a)}
function wz(a){wb.call(this,a)}
function zz(a){wb.call(this,a)}
function Cz(a){wb.call(this,a)}
function Sz(a){wb.call(this,a)}
function Wz(a){wz.call(this,a)}
function FA(a){wb.call(this,a)}
function $D(a){LD.call(this,a)}
function aE(a){vD.call(this,a)}
function ih(){jh.call(this,{})}
function zh(a){throw new Ng(a)}
function th(a){return new Xg(a)}
function vh(a){return new Ch(a)}
function dn(a){return new bn[a]}
function no(a){return Rr(),a.u}
function ax(a,b){return a.b==b}
function Oz(a,b){return a>b?a:b}
function Pz(a,b){return a<b?a:b}
function Ur(a){Rr();return true}
function nd(a){a=gA(a);return a}
function Wp(a){tc((mc(),lc),a)}
function Uq(a){uc((mc(),lc),a)}
function oo(a,b){po(a,(Rr(),b))}
function yt(a){po(this,(Rr(),a))}
function Vr(a,b){Rr();Hs(Pr,a,b)}
function Hs(a,b,c){ss(a);Is(b,c)}
function cp(a,b,c){Xq(a.n,b,c)}
function rp(a,b){_o(a.a,b,true)}
function rx(a,b){RC(a.d,b);wx(a)}
function wx(a){xx(a);yx(a);vx(a)}
function zu(a){po(this,(Rr(),a))}
function vu(){ku.call(this,ou())}
function Mt(){ab.call(this,db())}
function os(){zf.call(this,null)}
function ww(a){this.c=a;vw(this)}
function he(a){fe();Mb(ce,a);ie()}
function go(a){Yc(a.parentNode,a)}
function pd(a){return a.keyCode|0}
function Dd(a){return !!a.checked}
function Um(a){return a.l|a.m<<22}
function Uo(a,b){return Iq(a.n,b)}
function Vo(a,b){return Jq(a.n,b)}
function ir(a,b){return OC(a.k,b)}
function bt(a,b){return jv(a.b,b)}
function Zv(a,b){return a.f.pb(b)}
function qo(a,b){to((Rr(),a.u),b)}
function At(a,b){hd((Rr(),a.u),b)}
function xo(a,b){!!a.s&&yf(a.s,b)}
function sE(a,b){return $A(a.a,b)}
function uD(a,b){return a.b.ob(b)}
function bB(b,a){return b.e[qF+a]}
function qc(a){return !!a.a||!!a.f}
function Wc(a){return a.firstChild}
function wd(a){a.returnValue=false}
function Qw(a){a.a.K(a.d,a.c,a.b)}
function Sd(a,b){Id.call(this,a,b)}
function kg(a,b){Id.call(this,a,b)}
function ws(a,b){a.__listener=b}
function fD(a,b,c){a.splice(b,c)}
function zd(a,b){a.innerText=b||mF}
function hd(b,a){b.innerHTML=a||mF}
function Id(a,b){this.b=a;this.c=b}
function Ar(a,b){Id.call(this,a,b)}
function Yu(a,b){Id.call(this,a,b)}
function Sv(){Tv.call(this,new UC)}
function xv(){xv=LE;wv=yv()>=7}
function oA(){oA=LE;lA={};nA={}}
function Rs(){this.a=new zf(null)}
function dt(){this.b=new nv(this)}
function Ew(a,b){this.b=a;this.a=b}
function nx(a,b){this.b=a;this.a=b}
function OB(a,b){this.b=a;this.a=b}
function Gv(a,b){this.a=a;this.b=b}
function hy(a,b){this.a=a;this.b=b}
function zC(a,b){this.a=a;this.b=b}
function EE(a,b){this.a=a;this.b=b}
function On(){this.a='localStorage'}
function Nq(a){return !a.e?a.i:a.e}
function gC(a){return a.b<a.d.wb()}
function Xr(a){return rs((Rr(),a))}
function sh(a){return Gg(),a?Fg:Eg}
function gt(a,b){_s(a,b,(Rr(),a.u))}
function _o(a,b,c){Vq(a.n,b,c,true)}
function ex(a,b,c){dx(a,Xh(b,39),c)}
function tA(a,b){Qc(a.a,b);return a}
function uA(a,b){Rc(a.a,b);return a}
function zA(a,b){Rc(a.a,b);return a}
function _r(a){Zr();!!Yr&&Qs(Yr,a)}
function nt(a){mt();$f.call(this,a)}
function Iy(a){Gy();Dy.call(this,a)}
function Py(a){Ny();Dy.call(this,a)}
function Vd(){Sd.call(this,'NONE',0)}
function dv(){Yu.call(this,'LEFT',2)}
function mx(a){nx.call(this,a,false)}
function BA(a){yA(this);Rc(this.a,a)}
function Lu(a){jd((Rr(),a.u),yG,mF)}
function ou(){ju();return $doc.body}
function dB(b,a){return qF+a in b.e}
function hc(a,b){return Tc(a,b,null)}
function ai(a){return a==null?null:a}
function hE(a){return a<10?KF+a:mF+a}
function Wh(a,b){return a.cM&&a.cM[b]}
function cA(b,a){return b.indexOf(a)}
function cd(b,a){b.removeAttribute(a)}
function ic(a){$wnd.clearTimeout(a)}
function gD(a,b,c,d){a.splice(b,c,d)}
function vp(a,b,c){return wo(a.a,b,c)}
function xm(a){return ym(a.l,a.m,a.h)}
function UC(){this.a=Nh(om,PE,0,0,0)}
function zf(a){this.a=new Of;this.b=a}
function qn(a,b){zA(a.a,b.a);return a}
function VB(a,b){(a<0||a>=b)&&$B(a,b)}
function ed(c,a,b){c.setAttribute(a,b)}
function au(b,a){b.__gwt_resolve=bu(a)}
function Mu(a){yt.call(this,a);new ag}
function ep(a){fp.call(this,new pp(a))}
function Xd(){Sd.call(this,'BLOCK',1)}
function Zd(){Sd.call(this,'INLINE',2)}
function fv(){Yu.call(this,'RIGHT',3)}
function _u(){Yu.call(this,'CENTER',0)}
function pp(a){this.a=a;oo(this,this.a)}
function uc(a,b){a.c=xc(a.c,[b,false])}
function Vc(a,b){return a.childNodes[b]}
function Vh(a,b){return a.cM&&!!a.cM[b]}
function ec(a){return a.$H||(a.$H=++Xb)}
function _h(a){return a.tM==LE||Vh(a,1)}
function _z(b,a){return b.charCodeAt(a)}
function ym(a,b,c){return {l:a,m:b,h:c}}
function tE(a,b){return iB(a.a,b)!=null}
function Uc(b,a){return b.appendChild(a)}
function Yc(b,a){return b.removeChild(a)}
function Zo(a){var b;b=iq(a);!!b&&ad(b)}
function LD(a){vD.call(this,a);this.a=a}
function WD(a){GD.call(this,a);this.a=a}
function bv(){Yu.call(this,'JUSTIFY',1)}
function Gy(){Gy=LE;Cy();Fy=new Te}
function Ny(){Ny=LE;Cy();My=new Te}
function mt(){mt=LE;kt=new qt;lt=new tt}
function Je(){Je=LE;Ie=new Ue(uF,new Ke)}
function Ze(){Ze=LE;Ye=new Ue(vF,new $e)}
function $B(a,b){throw new Cz(AG+a+BG+b)}
function Zh(a,b){return a!=null&&Vh(a,b)}
function gn(c,a,b){return a.replace(c,b)}
function yB(a){return a.b=Xh(hC(a.a),62)}
function Qq(a){return (!a.e?a.i:a.e).k.b}
function Eb(a){return a==null?null:a.name}
function mb(){return (new Date).getTime()}
function Mf(){this.d=new oE;this.c=false}
function yb(a){this.e=!a?null:sb(a);Kc()}
function Sr(a,b){Rr();Uc(a,($t(),_t(b)))}
function cx(a,b,c,d){bx(a,b,Xh(c,39),d)}
function Ef(a,b,c){var d;d=Hf(a,b);d.mb(c)}
function If(a,b){var c;c=Jf(a,b);return c}
function OC(a,b){VB(b,a.b);return a.a[b]}
function Pq(a,b){return ir(!a.e?a.i:a.e,b)}
function Sn(a,b){return $wnd[a].getItem(b)}
function Cd(b,a){return b.getElementById(a)}
function fA(c,a,b){return c.substr(a,b-a)}
function $b(a,b,c){return a.apply(b,c);var d}
function $r(a){Zr();return Yr?Ns(Yr,a):null}
function Db(a){return a==null?null:a.message}
function ue(){return $doc.styleSheets.length}
function Ty(){wb.call(this,'divide by zero')}
function _d(){Sd.call(this,'INLINE_BLOCK',3)}
function Nz(){Nz=LE;Mz=Nh(nm,PE,53,256,0)}
function NC(a){a.a=Nh(om,PE,0,0,0);a.b=0}
function tc(a,b){a.a=xc(a.a,[b,false]);rc(a)}
function xc(a,b){!a&&(a=[]);Kb(a,b);return a}
function LC(a,b){Ph(a.a,a.b++,b);return true}
function EC(a){var b;b=yB(a.a);return b.Fb()}
function lq(a){var b;b=iq(a);!!b&&_c(b,_F)}
function kf(a){var b;if(gf){b=new hf;yf(a,b)}}
function Cf(a,b){!a.a&&(a.a=new UC);LC(a.a,b)}
function xf(a,b,c){return new Rf(Df(a.a,b,c))}
function Tf(a,b,c){return new Rf(Df(a.a,b,c))}
function Xc(c,a,b){return c.insertBefore(a,b)}
function Zc(c,a,b){return c.replaceChild(a,b)}
function jz(a){return typeof a=='number'&&a>0}
function iz(a){var b=bn[a.b];a=null;return b}
function Eq(){Eq=LE;yq=new jn((Jn(),new Gn))}
function oe(){oe=LE;me();ne=Nh(em,PE,-1,30,1)}
function fe(){fe=LE;ce=[];de=[];ee=[];ae=new ke}
function ss(a){if(!qs){Gs();new ys(a);qs=true}}
function fs(){as&&kf((!bs&&(bs=new os),bs))}
function qq(a){rq.call(this,a,!gq&&(gq=new Aq))}
function yu(){zu.call(this,(Rr(),ud($doc,sF)))}
function sr(a,b,c){Id.call(this,a,b);this.a=c}
function Px(a,b,c){Id.call(this,a,b);this.a=c}
function io(a,b,c){this.b=a;this.c=b;this.a=c}
function Tw(a,b,c){this.a=a;this.c=b;this.b=c}
function Ww(a,b,c){this.a=a;this.c=b;this.b=c}
function nv(a){this.b=a;this.a=Nh(lm,PE,32,4,0)}
function Wv(a){a.f.nb();a.i=a.g=0;a.j=true;Xv(a)}
function lu(a){ju();try{a.X()}finally{tE(iu,a)}}
function eA(b,a){return b.substr(a,b.length-a)}
function $h(a){return a!=null&&a.tM!=LE&&!Vh(a,1)}
function Ch(a){if(a==null){throw new Rz}this.a=a}
function at(a,b){if(b<0||b>=a.b.c){throw new Bz}}
function Tn(a,b){Sn(a,QF);$wnd[a].setItem(QF,b)}
function Bp(a,b){a.a.j=true;mq(a.a,b);a.a.j=false}
function Ap(a,b,c,d){a.a.i=a.a.i||d;pq(a.a,b,c,d)}
function Rp(){Mp=iF(function(){_p($wnd.event)})}
function dr(c){c.sort(function(a,b){return a-b})}
function No(a){if(a.p){return a.p.U()}return false}
function Jb(a){var b;return b=a,_h(b)?b.hC():ec(b)}
function cs(a){es();return ds(gf?gf:(gf=new Te),a)}
function Os(a){return encodeURI(a).replace(qG,rG)}
function Xf(a){xb.call(this,Zf(a),Yf(a));this.a=a}
function jn(a){this.b=0;this.c=0;this.a=26;this.d=a}
function Pt(a){this.a=a;this.b=cg(a);this.c=this.b}
function Yz(a){this.a='Unknown';this.c=a;this.b=-1}
function jr(a){this.k=new UC;this.n=new uE;this.f=a}
function ju(){ju=LE;gu=new qu;hu=new oE;iu=new uE}
function Nr(){Nr=LE;Lr=new Jr;Mr=new Jr;Kr=new Jr}
function Zr(){Zr=LE;Yr=new Rs;Ps(Yr)?null:(Yr=null)}
function Sh(){Sh=LE;Qh=[];Rh=[];Th(new Jh,Qh,Rh)}
function TA(a){var b;b=new sB(a);return new zC(a,b)}
function rE(a,b){var c;c=eB(a.a,b,a);return c==null}
function rf(a,b){var c;if(nf){c=new pf(b);yf(a.a,c)}}
function _v(a,b){aw.call(this,a,b,null,0);Cv(a,b.b)}
function Xt(){Ut();Yt.call(this,(Rr(),ud($doc,sF)))}
function ie(){fe();if(!be){be=true;uc((mc(),lc),ae)}}
function rA(){if(mA==256){lA=nA;nA={};mA=0}++mA}
function ci(a){if(a!=null){throw new nz}return null}
function ln(a){if(a==null){throw new Sz(LF)}this.a=a}
function tn(a){if(a==null){throw new Sz(LF)}this.a=a}
function nD(a){lD();return a?new $D(a):new LD(null)}
function zp(a){a.b&&(!Jp&&(Jp=new Yp),Wp(new Ep(a)))}
function ds(a,b){return xf((!bs&&(bs=new os),bs),a,b)}
function Mm(a,b){return a.l==b.l&&a.m==b.m&&a.h==b.h}
function Wm(a,b){return {l:a.l^b.l,m:a.m^b.m,h:a.h^b.h}}
function Iq(a,b){return vp(a.j,b,(!Iv&&(Iv=new Te),Iv))}
function Jq(a,b){return vp(a.j,b,(!Jw&&(Jw=new Te),Jw))}
function Ns(a,b){return xf(a.a,(!nf&&(nf=new Te),nf),b)}
function bd(b,a){return b[a]==null?null:String(b[a])}
function Ib(a,b){var c;return c=a,_h(c)?c.eQ(b):c===b}
function Rv(a,b){var c;c=a.a.f.wb();c>0&&Ev(b,0,a.a)}
function yC(a){var b;b=new AB(a.b.a);return new FC(b)}
function Gg(){Gg=LE;Eg=new Hg(false);Fg=new Hg(true)}
function Zy(){Zy=LE;Xy=new $y(false);Yy=new $y(true)}
function ZA(a){a.a=[];a.e={};a.c=false;a.b=null;a.d=0}
function Nw(a){var b;if(Jw){b=new Lw;!!a.s&&yf(a.s,b)}}
function nE(a,b){return ai(a)===ai(b)||a!=null&&Ib(a,b)}
function KE(a,b){return ai(a)===ai(b)||a!=null&&Ib(a,b)}
function wo(a,b,c){return xf(!a.s?(a.s=new zf(a)):a.s,c,b)}
function Oq(a){return (zr(),xr)==a.d?-1:(!a.e?a.i:a.e).d}
function _t(a){return a.__gwt_resolve?a.__gwt_resolve():a}
function Sq(a){return (!a.e?a.i:a.e).j&&(!a.e?a.i:a.e).i==0}
function jc(){return hc(function(){Wb!=0&&(Wb=0);Zb=-1},10)}
function gc(a){$wnd.setTimeout(function(){throw a},0)}
function ku(a){dt.call(this);po(this,(Rr(),a));yo(this)}
function Ht(){dt.call(this);po(this,(Rr(),ud($doc,sF)))}
function Rw(a,b,c){this.a=a;this.d=b;this.c=null;this.b=c}
function Nh(a,b,c,d,e){var f;f=Mh(e,d);Oh(a,b,c,f);return f}
function Xh(a,b){if(a!=null&&!Wh(a,b)){throw new nz}return a}
function eh(a,b){if(b==null){throw new Rz}return fh(a,b)}
function iv(a,b){if(b<0||b>=a.c){throw new Bz}return a.a[b]}
function te(a){if(ue()==0){return qe(a)}return pe(0,a,false)}
function mD(a){lD();var b;b=new vE;rE(b,a);return new aE(b)}
function Rb(a){var b=Ob[a.charCodeAt(0)];return b==null?a:b}
function vd(a,b){var c=a.createEventObject();c.type=b;return c}
function gp(a,b,c){Rr();ws(b,a);hd(b,c.a);ws(b,null);return b}
function KC(a,b,c){(b<0||b>a.b)&&$B(b,a.b);gD(a.a,b,0,c);++a.b}
function sx(a,b){lx(b,gA(b.b));!b.b.length&&RC(a.d,b);wx(a)}
function dy(a,b){by(a.g,(Ox(),Mx),b);by(a.f,Lx,b);by(a.i,Nx,b)}
function Ot(a,b){hd(a.a,b);if(a.c!=a.b){a.c=a.b;dg(a.a,a.b)}}
function dA(c,a,b){b=hA(b);return c.replace(RegExp(a,NF),b)}
function aA(a,b){if(!Zh(b,1)){return false}return String(a)==b}
function md(a){if($c(a)){return !!a&&a.nodeType==1}return false}
function $p(a){if(aq(a)){return Zy(),Dd(a)?Yy:Xy}return a.value}
function mu(){ju();try{ot(iu,gu)}finally{ZA(iu.a);ZA(hu)}}
function fo(){if(!co){co=ud($doc,sF);to(co,false);Uc(ou(),co)}}
function by(a,b,c){b==c?_c((Rr(),a.u),GG):dd((Rr(),a.u),GG)}
function ap(a,b){if(a.k){Qw(a.k.a);a.k=null}!!b&&(a.k=Iq(a.n,b))}
function iC(a){if(a.c<0){throw new yz}a.d.ub(a.c);a.b=a.c;a.c=-1}
function rv(a){if(!a.a){throw new yz}a.c.b.gb(a.a);--a.b;a.a=null}
function Rq(a){return new Ew((!a.e?a.i:a.e).g,(!a.e?a.i:a.e).f)}
function Tv(a){this.b=new uE;this.e=new oE;this.a=new _v(this,a)}
function mv(a,b){var c;c=jv(a,b);if(c==-1){throw new JE}lv(a,c)}
function xd(a,b){var c=a.getAttribute(b);return c==null?mF:c+mF}
function sb(a){var b,c;b=a.cZ.c;c=a.A();return c!=null?b+jF+c:b}
function us(a){var b=a.__listener;return !$h(b)&&Zh(b,24)?b:null}
function cc(a,b,c){var d;d=ac();try{return $b(a,b,c)}finally{dc(d)}}
function SC(a,b,c){var d;d=(VB(b,a.b),a.a[b]);Ph(a.a,b,c);return d}
function gz(a,b,c){var d;d=new ez;d.c=a+b;jz(c)&&kz(c,d);return d}
function Oh(a,b,c,d){Sh();Uh(d,Qh,Rh);d.cZ=a;d.cM=b;d.qI=c;return d}
function Jv(a,b,c,d,e){this.f=a;this.b=b;this.a=c;this.d=d;this.e=e}
function Cb(a){Ab();vb.call(this);this.a=mF;this.b=a;this.a=mF;Jc()}
function $(a){if(!a.e){return}a.g=a.f;a.e=false;a.f=false;a.g&&Kt(a)}
function gB(a,b){var c;c=a.b;a.b=b;if(!a.c){a.c=true;++a.d}return c}
function Lh(a,b){var c,d;c=a;d=Mh(0,b);Oh(c.cZ,c.cM,c.qI,d);return d}
function Wt(a,b){var c;a.c=b;c=(Zr(),Yr?Os(b):b);jd(a.a,'href',qG+c)}
function _s(a,b,c){Ao(b);hv(a.b,b);Rr();Uc(c,($t(),_t(b.u)));Bo(b,a)}
function hh(d,a,b){if(b){var c=b.L();d.a[a]=c(b)}else{delete d.a[a]}}
function tg(d,a,b){if(b){var c=b.L();b=c(b)}else{b=undefined}d.a[a]=b}
function Uh(a,b,c){Sh();for(var d=0,e=b.length;d<e;++d){a[b[d]]=c[d]}}
function hD(a,b,c,d){Array.prototype.splice.apply(a,[b,c].concat(d))}
function qe(a){var b;b=$doc.createStyleSheet();b.cssText=a;return b}
function kB(a){var b;b=a.b;a.b=null;if(a.c){a.c=false;--a.d}return b}
function Yh(a){if(a!=null&&(a.tM==LE||Vh(a,1))){throw new nz}return a}
function bu(a){return function(){this.__gwt_resolve=cu;return a.R()}}
function $c(b){try{return !!b&&!!b.nodeType}catch(a){return false}}
function cu(){throw 'A PotentialElement cannot be resolved twice.'}
function Jn(){Jn=LE;new RegExp('%5B',NF);new RegExp('%5D',NF)}
function fx(a,b,c){var d;d=new rn;dx(a,c,d);hd(b,(new tn(d.a.a.a)).a)}
function QC(a,b){var c;c=(VB(b,a.b),a.a[b]);fD(a.a,b,1);--a.b;return c}
function Lq(a){!a.e&&(a.e=new lr(a.i));a.f=new fr(a);Uq(a.f);return a.e}
function Bd(a){!a.gwt_uid&&(a.gwt_uid=1);return 'gwt-uid-'+a.gwt_uid++}
function hC(a){if(a.b>=a.d.wb()){throw new JE}return a.d.pb(a.c=a.b++)}
function se(a){var b;b=ue();if(b==0){return qe(a)}return pe(b-1,a,true)}
function eo(a){var b,c;fo();b=sd(a);c=rd(a);Uc(co,a);return new io(b,c,a)}
function St(a){dt.call(this);oo(this,ud($doc,sF));hd((Rr(),this.u),a)}
function Yo(a,b,c){var d;d=gp(a,(!To&&(To=ud($doc,sF)),To),c);lp(a.c,d,b)}
function Kh(a,b){var c,d;c=a;d=c.slice(0,b);Oh(c.cZ,c.cM,c.qI,d);return d}
function PC(a,b,c){for(;c<a.b;++c){if(KE(b,a.a[c])){return c}}return -1}
function Yf(a){var b;b=a.hb();if(!b.jb()){return null}return Xh(b.kb(),57)}
function gs(){var a;if(as){a=new ks;!!bs&&yf(bs,a);return null}return null}
function sd(a){var b=a.parentNode;(!b||b.nodeType!=1)&&(b=null);return b}
function qv(a){if(a.b>=a.c.c){throw new JE}a.a=a.c.a[a.b];++a.b;return a.a}
function um(a){if(Zh(a,57)){return a}return a==null?new Cb(null):sm(a)}
function iA(a,b,c){a=a.slice(b,c);return String.fromCharCode.apply(null,a)}
function Rn(){this.a=$wnd.localStorage!=null;$wnd.sessionStorage!=null}
function dc(a){a&&oc((mc(),lc));--Wb;if(a){if(Zb!=-1){ic(Zb);Zb=-1}}}
function Th(a,b,c){var d=0,e;for(var f in a){if(e=a[f]){b[d]=f;c[d]=e;++d}}}
function hB(e,a,b){var c,d=e.e;a=qF+a;a in d?(c=d[a]):++e.d;d[a]=b;return c}
function jv(a,b){var c;for(c=0;c<a.c;++c){if(a.a[c]==b){return c}}return -1}
function Co(a,b){a.r==-1?Vr((Rr(),a.u),b|(a.u.__eventBits||0)):(a.r|=b)}
function ay(a,b){b?Fd(a.style,WF,(Rd(),RF)):Fd(a.style,WF,(Rd(),'block'))}
function dp(a,b){if(!a){return}b?Fd(a.style,WF,mF):Fd(a.style,WF,(Rd(),RF))}
function $A(a,b){return b==null?a.c:Zh(b,1)?dB(a,Xh(b,1)):cB(a,b,~~Jb(b))}
function _A(a,b){return b==null?a.b:Zh(b,1)?bB(a,Xh(b,1)):aB(a,b,~~Jb(b))}
function iB(a,b){return b==null?kB(a):Zh(b,1)?lB(a,Xh(b,1)):jB(a,b,~~Jb(b))}
function bi(a){return ~~Math.max(Math.min(a,2147483647),-2147483648)}
function eu(b){$t();try{return !!b&&!!b.__gwt_resolve}catch(a){return false}}
function RC(a,b){var c;c=PC(a,b,0);if(c==-1){return false}QC(a,c);return true}
function gh(a,b,c){var d;if(b==null){throw new Rz}d=eh(a,b);hh(a,b,c);return d}
function hz(a,b,c,d){var e;e=new ez;e.c=a+b;jz(c)&&kz(c,e);e.a=d?8:0;return e}
function _w(a,b,c){var d;d=Wc(b.firstChild);lx(c,d.value);vf(a.c,new Py(c))}
function $o(a,b,c){if(c){kd(b,a.o)}else{kd(b,-1);cd(b,VF);cd(b,'accessKey')}}
function aw(a,b,c,d){this.n=a;this.d=new sw(this);this.f=b;this.b=c;this.k=d}
function Lv(a,b,c,d,e,f){var g;g=new Jv(b,c,d,e,f);!!Iv&&!!a.s&&yf(a.s,g);return g}
function qd(a){var b=a.firstChild;while(b&&b.nodeType!=1)b=b.nextSibling;return b}
function rd(a){var b=a.nextSibling;while(b&&b.nodeType!=1)b=b.nextSibling;return b}
function lB(d,a){var b,c=d.e;a=qF+a;if(a in c){b=c[a];--d.d;delete c[a]}return b}
function sg(d,a){var b=d.a[a];var c=(rh(),qh)[typeof b];return c?c(b):Ah(typeof b)}
function nc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=yc(b,c)}while(a.b);a.b=c}}
function oc(a){var b,c;if(a.c){c=null;do{b=a.c;a.c=null;c=yc(b,c)}while(a.c);a.c=c}}
function Zw(){var a;Pu();Qu.call(this,(a=$doc.createElement(CG),a.type='text',a))}
function ht(a){Fd(a.style,'left',mF);Fd(a.style,'top',mF);Fd(a.style,'position',mF)}
function Wq(a,b){if(!b){throw new Sz('KeyboardSelectionPolicy cannot be null')}a.d=b}
function Pn(){if((!Mn&&(Mn=new Rn),Mn).a){!Ln&&(Ln=new On);return Ln}return null}
function Qb(){Qb=LE;Ob=Ub();Pb=typeof JSON=='object'&&typeof JSON.parse==oF}
function zc(b,c){mc();hc(function(){var a=iF(wc)(b);a&&hc(arguments.callee,c)},c)}
function bc(b){return function(){try{return cc(b,this,arguments)}catch(a){throw a}}}
function bA(b,a){if(a==null)return false;return b==a||b.toLowerCase()==a.toLowerCase()}
function Tc(a,b,c){var d=$wnd.setTimeout(function(){a();c!=null&&_b(c)},b);return d}
function fz(a,b,c){var d;d=new ez;d.c=a+b;jz(c!=0?-c:0)&&kz(c!=0?-c:0,d);d.a=4;return d}
function ux(a,b){var c,d;for(d=new jC(a.d);d.b<d.d.wb();){c=Xh(hC(d),39);c.a=b}wx(a)}
function qx(a){var b,c;c=new jC(a.d);while(c.b<c.d.wb()){b=Xh(hC(c),39);b.a&&iC(c)}wx(a)}
function Dv(a,b,c){var d,e;for(e=yC(TA(a.b.a));gC(e.a.a);){d=Xh(EC(e),34);Ev(d,b,c)}}
function eB(a,b,c){return b==null?gB(a,c):Zh(b,1)?hB(a,Xh(b,1),c):fB(a,b,c,~~Jb(b))}
function oC(a,b){var c;this.a=a;jC.call(this,a);c=a.wb();(b<0||b>c)&&$B(b,c);this.b=b}
function _q(a,b){this.c=(rr(),or);this.d=(zr(),yr);this.a=a;this.j=b;this.i=new jr(25)}
function to(a,b){a.style.display=b?mF:RF;b?a.removeAttribute(SF):a.setAttribute(SF,TF)}
function wm(a){var b,c,d;b=a&4194303;c=a>>22&4194303;d=a<0?1048575:0;return ym(b,c,d)}
function Iz(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function dh(e,a){var b=e.a;var c=0;for(var d in b){b.hasOwnProperty(d)&&(a[c++]=d)}return a}
function iq(a){var b;b=Oq(a.n);if(b>=0&&a.c.childNodes.length>b){return Vc(a.c,b)}return null}
function jq(a,b){Tq(a.n,null);Wo(a,b);if(a.c.childNodes.length>b){return Vc(a.c,b)}return null}
function Vv(a,b){var c;c=a.f.mb(b);a.i=Pz(a.i,a.f.wb()-1);a.g=a.f.wb();a.j=true;Xv(a);return c}
function HA(a,b){var c;while(a.jb()){c=a.kb();if(b==null?c==null:Ib(b,c)){return a}}return null}
function Gt(a,b){var c;at(a,b);c=a.a;a.a=iv(a.b,b);if(a.a!=c){!Et&&(Et=new Mt);Lt(Et,c,a.a)}}
function pc(a){var b;if(a.a){b=a.a;a.a=null;!a.f&&(a.f=[]);yc(b,a.f)}!!a.f&&(a.f=sc(a.f))}
function AB(a){var b;this.c=a;b=new UC;a.c&&LC(b,new JB(a));YA(a,b);XA(a,b);this.a=new jC(b)}
function xw(a,b){var c;this.c=a;vw(this);c=a.f.wb();if(b<0||b>c){throw new Cz(AG+b+BG+c)}this.a=b}
function yd(a){var b,c;c=a.tagName;b=a.scopeName;if(b==null||bA('html',b)){return c}return b+qF+c}
function tm(a){var b;if(Zh(a,2)){b=Xh(a,2);if(b.b!==(Ab(),zb)){return b.b===zb?null:b.b}}return a}
function Tr(a,b,c){Rr();var d;d=Or;Or=a;b==Qr&&rs(a.type)==8192&&(Qr=null);c.W(a);Or=d}
function Xq(a,b,c){if(b==(!a.e?a.i:a.e).i&&c==(!a.e?a.i:a.e).j){return}Lq(a).i=b;Lq(a).j=c;$q(a)}
function rc(a){if(!a.i){a.i=true;!a.e&&(a.e=new Bc(a));zc(a.e,1);!a.g&&(a.g=new Ec(a));zc(a.g,50)}}
function Cv(a,b){var c,d;a.c=b;a.d=true;for(d=yC(TA(a.b.a));gC(d.a.a);){c=Xh(EC(d),34);c.ab(b,true)}}
function MC(a,b){var c,d;c=b.yb();d=c.length;if(d==0){return false}hD(a.a,a.b,0,c);a.b+=d;return true}
function Fm(a){var b,c;c=Hz(a.h);if(c==32){b=Hz(a.m);return b==32?Hz(a.l)+32:b+20-10}else{return c-12}}
function sm(b){var c=b.__gwt$exception;if(!c){c=new Cb(b);try{b.__gwt$exception=c}catch(a){}}return c}
function Qs(a,b){b=b==null?mF:b;if(!aA(b,Ms==null?mF:Ms)){Ms=b;$wnd.location.hash=a.eb(b);rf(a,b)}}
function gx(){hb.call(this,Oh(qm,PE,1,[uF,vF,YF,kG]));this.b=null;this.a=false;this.c=(Cy(),Cy(),By)}
function Qu(a){Mu.call(this,a,(!Zn&&(Zn=new $n),!Wn&&(Wn=new Xn)));fd((Rr(),this.u),'gwt-TextBox')}
function Xu(){Xu=LE;Tu=new _u;Uu=new bv;Vu=new dv;Wu=new fv;Su=Oh(km,PE,31,[Tu,Uu,Vu,Wu])}
function Rd(){Rd=LE;Qd=new Vd;Nd=new Xd;Od=new Zd;Pd=new _d;Md=Oh(fm,PE,3,[Qd,Nd,Od,Pd])}
function _m(){_m=LE;Xm=ym(4194303,4194303,524287);Ym=ym(0,0,524288);Zm=Om(1);Om(2);$m=Om(0)}
function rh(){rh=LE;qh={'boolean':sh,number:th,string:vh,object:uh,'function':uh,undefined:wh}}
function Wo(a,b){if(!(b>=0&&b<Qq(a.n))){throw new Cz('Row index: '+b+', Row size: '+Nq(a.n).i)}}
function kp(a,b,c){No(a)||(Rr(),ws(a.u,a));hd(b,(!Jp&&(Jp=new Yp),Vp(Jp,c)).a);No(a)||(Rr(),ws(a.u,null))}
function px(a){var b,c;b=gA(bd(no(a.e.j),yG));if(aA(b,mF))return;c=new mx(b);Lu(a.e.j);LC(a.d,c);wx(a)}
function bq(a){var b,c,d;if(!Np){return}c=$p(Np);if(!Ib(c,Pp)){Pp=c;d=Np;b=vd($doc,aG);Zp(a,d,1024,b)}}
function vf(b,c){var d;try{Ff(b.a,c)}catch(a){a=um(a);if(Zh(a,38)){d=a;throw new $f(d.a)}else throw tm(a)}}
function Bm(a,b,c,d,e){var f;f=Rm(a,b);c&&Em(f);if(e){a=Dm(a,b);d?(vm=Pm(a)):(vm=ym(a.l,a.m,a.h))}return f}
function Fs(a,b){var c=a.children.length;for(var d=0;d<c;++d){if(b===a.children[d]){return d}}return -1}
function xu(a,b){if(a.a!=b){return false}try{Bo(b,null)}finally{Yc((Rr(),a.u),b.u);a.a=null}return true}
function vy(a){if(!a.a){a.a=true;fe();Mb(ce,'.GMY2FQLEI{display:inline;}');ie();return true}return false}
function cg(a){var b;b=bd(a,yF);if(bA(zF,b)){return jg(),ig}else if(bA(AF,b)){return jg(),hg}return jg(),gg}
function qA(a){oA();var b=qF+a;var c=nA[b];if(c!=null){return c}c=lA[b];c==null&&(c=pA(a));rA();return nA[b]=c}
function YA(e,a){var b=e.e;for(var c in b){if(c.charCodeAt(0)==58){var d=new OB(e,c.substring(1));a.mb(d)}}}
function xx(a){var b,c;Wv(a.b.a);for(c=new jC(a.d);c.b<c.d.wb();){b=Xh(hC(c),39);a.c.a.Bb(b)&&Vv(a.b.a,b)}}
function yx(a){var b,c,d,e;e=a.d.b;b=0;for(d=new jC(a.d);d.b<d.d.wb();){c=Xh(hC(d),39);c.a&&++b}ey(a.e,e,b)}
function Kf(a){var b,c;if(a.a){try{for(c=new jC(a.a);c.b<c.d.wb();){b=Xh(hC(c),37);b.D()}}finally{a.a=null}}}
function lv(a,b){var c;if(b<0||b>=a.c){throw new Bz}--a.c;for(c=b;c<a.c;++c){Ph(a.a,c,a.a[c+1])}Ph(a.a,a.c,null)}
function zB(a){if(!a.b){throw new zz('Must call next() before remove().')}else{iC(a.a);iB(a.c,a.b.Fb());a.b=null}}
function Ah(a){rh();throw new Ng("Unexpected typeof result '"+a+"'; please report this bug to the GWT team")}
function Ct(){Bt.call(this,$doc.createElement("<BUTTON type='button'><\/BUTTON>"));fd((Rr(),this.u),'gwt-Button')}
function jg(){jg=LE;ig=new kg('RTL',0);hg=new kg('LTR',1);gg=new kg('DEFAULT',2);fg=Oh(gm,PE,13,[ig,hg,gg])}
function of(a,b){var c;c=Xh(a.a,1);b.a.c=aA(c,wF)?(Ox(),Lx):aA(c,xF)?(Ox(),Nx):(Ox(),Mx);dy(b.a.e,b.a.c);xx(b.a)}
function ct(a,b){var c;if(b.t!=a){return false}try{Bo(b,null)}finally{c=(Rr(),b.u);Yc(sd(c),c);mv(a.b,b)}return true}
function ac(){var a;if(Wb!=0){a=mb();if(a-Yb>2000){Yb=a;Zb=jc()}}if(Wb++==0){nc((mc(),lc));return true}return false}
function Lz(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Nz(),Mz)[b];!c&&(c=Mz[b]=new Ez(a));return c}return new Ez(a)}
function Pm(a){var b,c,d;b=~a.l+1&4194303;c=~a.m+(b==0?1:0)&4194303;d=~a.h+(b==0&&c==0?1:0)&1048575;return ym(b,c,d)}
function Jc(){var a,b,c,d;c=[];d=Nh(pm,PE,56,c.length,0);for(a=0,b=d.length;a<b;a++){d[a]=new Yz(c[a])}rb(d)}
function Kc(){var a,b,c,d;c=Ic(new Mc);d=Nh(pm,PE,56,c.length,0);for(a=0,b=d.length;a<b;a++){d[a]=new Yz(c[a])}rb(d)}
function rb(a){var b,c,d;c=Nh(pm,PE,56,a.length,0);for(d=0,b=a.length;d<b;++d){if(!a[d]){throw new Rz}c[d]=a[d]}}
function Hf(a,b){var c,d;d=Xh(_A(a.d,b),61);if(!d){d=new oE;eB(a.d,b,d)}c=Xh(d.b,60);if(!c){c=new UC;gB(d,c)}return c}
function Jf(a,b){var c,d;d=Xh(_A(a.d,b),61);if(!d){return lD(),lD(),kD}c=Xh(d.b,60);if(!c){return lD(),lD(),kD}return c}
function nu(){ju();var a;a=Xh(_A(hu,null),29);if(a){return a}hu.d==0&&cs(new tu);a=new vu;eB(hu,null,a);rE(iu,a);return a}
function pe(a,b,c){var d;d=$doc.styleSheets[a];c?(d.cssText+=b,undefined):(d.cssText=b+d.cssText,undefined);return d}
function _c(a,b){var c,d;b=nd(b);d=a.className;c=ld(d,b);if(c==-1){d.length>0?fd(a,d+rF+b):fd(a,b);return true}return false}
function rB(a,b){var c,d,e;if(Zh(b,62)){c=Xh(b,62);d=c.Fb();if($A(a.a,d)){e=_A(a.a,d);return nE(c.Gb(),e)}}return false}
function Gf(a,b,c){var d,e,f;d=Jf(a,b);e=d.vb(c);e&&d.rb()&&(f=Xh(_A(a.d,b),61),Xh(kB(f),60),f.d==0&&iB(a.d,b),undefined)}
function Tm(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return {l:c&4194303,m:d&4194303,h:e&1048575}}
function aq(a){var b;if(!a||!bA(fG,yd(a))){return false}b=a.type.toLowerCase();return aA('checkbox',b)||aA('radio',b)}
function Tp(a,b){var c;return sE(a.c,yd(b).toLowerCase())||(c=b.getAttributeNode(VF),c!=null&&c.specified?b.tabIndex:-1)>=0}
function TC(a,b){var c;b.length<a.b&&(b=Lh(b,a.b));for(c=0;c<a.b;++c){Ph(b,c,a.a[c])}b.length>a.b&&Ph(b,a.b,null);return b}
function oq(a){var b;b=Oq(a.n);if(b>=0&&b<Nq(a.n).k.b){iq(a);Wo(a,b);Pq(a.n,b);new jb(b+Rq(a.n).b,a.n);return false}return false}
function cz(a){if(a>=48&&a<58){return a-48}if(a>=97&&a<97){return a-97+10}if(a>=65&&a<65){return a-65+10}return -1}
function Am(a,b){if(a.h==524288&&a.m==0&&a.l==0){b&&(vm=ym(0,0,0));return xm((_m(),Zm))}b&&(vm=ym(a.l,a.m,a.h));return ym(0,0,0)}
function _x(a,b){var c;c=a.o;Rr();Hs(Pr,c,1);ws(c,new hy(a,b));vo(a.j,new ky(b),(Ze(),Ze(),Ye));vo(a.a,new ny(b),(Je(),Je(),Ie))}
function Ue(a,b){var c;Te.call(this);this.a=b;!De&&(De=new ef);c=Xh(cf(De,a),60);if(!c){c=new UC;df(De,a,c)}c.mb(this);this.b=a}
function ug(a){var b,c,d;d=new vA;Rc(d.a,BF);for(c=0,b=a.a.length;c<b;c++){c>0&&(Rc(d.a,CF),d);tA(d,sg(a,c))}Rc(d.a,DF);return d.a.a}
function Em(a){var b,c,d;b=~a.l+1&4194303;c=~a.m+(b==0?1:0)&4194303;d=~a.h+(b==0&&c==0?1:0)&1048575;Im(a,b);Jm(a,c);Hm(a,d)}
function mq(a,b){var c;c=null;b==(Nr(),Lr)?(c=a.e):b==Kr&&Sq(a.n)&&(c=a.d);!!c&&Gt(a.f,bt(a.f,c));dp(a.c,!c);qo(a.f,!!c);xo(a,new Fr)}
function pq(a,b,c,d){var e;if(!(b>=0&&b<Nq(a.n).k.b)){return}e=jq(a,b);(!c||a.i||d)&&so(e,_F,c);$o(a,e,c);if(c&&d&&!a.b){ad(e);lq(a)}}
function Zp(a,b,c,d){if(!Ad((Rr(),a.u),b)){return}ws(b,a);Vr(b,c|(b.__eventBits||0));!!d&&(b.fireEvent('on'+d.type,d),undefined)}
function gwtOnLoad(b,c,d,e){$moduleName=c;$moduleBase=d;if(b)try{iF(rm)()}catch(a){b(c)}else{iF(rm)()}}
function dg(a,b){switch(b.c){case 0:{jd(a,yF,zF);break}case 1:{jd(a,yF,AF);break}case 2:{cg(a)!=(jg(),gg)&&jd(a,yF,mF);break}}}
function zr(){zr=LE;xr=new Ar('DISABLED',0);yr=new Ar('ENABLED',1);wr=new Ar('BOUND_TO_SELECTION',2);vr=Oh(jm,PE,23,[xr,yr,wr])}
function Ox(){Ox=LE;Mx=new Px('ALL',0,new Vx);Lx=new Px('ACTIVE',1,new Sx);Nx=new Px('COMPLETED',2,new Yx);Kx=Oh(mm,PE,40,[Mx,Lx,Nx])}
function Dn(){Dn=LE;new tn(mF);yn=new RegExp(MF,NF);zn=new RegExp(OF,NF);An=new RegExp(tF,NF);Cn=new RegExp(PF,NF);Bn=new RegExp(pF,NF)}
function es(){var a;if(!as){a=od($doc);Uc($doc.body,a);$wnd.__gwt_initWindowCloseHandler(iF(gs),iF(fs));Yc($doc.body,a);as=true}}
function XA(h,a){var b=h.a;for(var c in b){var d=parseInt(c,10);if(c==d){var e=b[d];for(var f=0,g=e.length;f<g;++f){a.mb(e[f])}}}}
function aB(h,a,b){var c=h.a[b];if(c){for(var d=0,e=c.length;d<e;++d){var f=c[d];var g=f.Fb();if(h.Eb(a,g)){return f.Gb()}}}return null}
function cB(h,a,b){var c=h.a[b];if(c){for(var d=0,e=c.length;d<e;++d){var f=c[d];var g=f.Fb();if(h.Eb(a,g)){return true}}}return false}
function wp(b,c,d){var e;try{e=new rn;nq(b.a,e,c,d);return new tn(e.a.a.a)}catch(a){a=um(a);if(Zh(a,58)){return null}else throw tm(a)}}
function gA(c){if(c.length==0||c[0]>rF&&c[c.length-1]>rF){return c}var a=c.replace(/^(\s*)/,mF);var b=a.replace(/\s*$/,mF);return b}
function Om(a){var b,c;if(a>-129&&a<128){b=a+128;Lm==null&&(Lm=Nh(hm,PE,18,256,0));c=Lm[b];!c&&(c=Lm[b]=wm(a));return c}return wm(a)}
function Js(){var a=false;for(var b=0;b<$wnd.__gwt_globalEventArray.length;b++){!$wnd.__gwt_globalEventArray[b]()&&(a=true)}return !a}
function fh(f,a){var b=f.a;var c;a=String(a);b.hasOwnProperty(a)&&(c=b[a]);var d=(rh(),qh)[typeof c];var e=d?d(c):Ah(typeof c);return e}
function ts(a){var b,c,d,e;b=$doc.getElementsByTagName('*');for(d=0;d<b.length;d++){c=b[d];e=us(c);if(e){ss(a);Is(c,0);ws(c,null)}vs(c)}}
function hb(a){var b,c,d,e;e=null;if(a!=null&&a.length>0){e=new uE;for(c=0,d=a.length;c<d;++c){b=a[c];rE(e,b)}}!!e&&(this.d=(lD(),new aE(e)))}
function hA(a){var b;b=0;while(0<=(b=a.indexOf('\\',b))){a.charCodeAt(b+1)==36?(a=fA(a,0,b)+'$'+eA(a,++b)):(a=fA(a,0,b)+eA(a,++b))}return a}
function vo(a,b,c){var d;d=Xr(c.b);d==-1?Rr():a.r==-1?Vr((Rr(),a.u),d|(a.u.__eventBits||0)):(a.r|=d);return xf(!a.s?(a.s=new zf(a)):a.s,c,b)}
function ey(a,b,c){var d;d=b-c;ay(a.c,b==0);ay(a.k,b==0);ay((Rr(),a.a.u),c==0);zd(a.d,mF+d);zd(a.e,d>1||d==0?'items':'item');hd(a.b,mF+c);Ed(a.o,b==c)}
function yy(a){var b;b=new AA;Rc(b.a,"Clear completed (<span class='number-done' id='");zA(b,En(a));Rc(b.a,"'><\/span>)");return new ln(b.a.a)}
function $q(a){var b,c,d;d=(!a.e?a.i:a.e).g;b=Oz(0,Pz((!a.e?a.i:a.e).f,(!a.e?a.i:a.e).i-d));c=(!a.e?a.i:a.e).k.b-1;while(c>=b){QC(Lq(a).k,c);--c}}
function rr(){rr=LE;pr=new sr('CURRENT_PAGE',0,true);or=new sr('CHANGE_PAGE',1,false);qr=new sr('INCREASE_RANGE',2,false);nr=Oh(im,PE,22,[pr,or,qr])}
function Xv(a){if(a.b){a.b.i=Pz(a.i+a.k,a.b.i);a.b.g=Oz(a.g+a.k,a.b.g);a.b.j=a.j||a.b.j;Xv(a.b);return}a.c=false;if(!a.e){a.e=true;uc((mc(),lc),a.d)}}
function Ev(a,b,c){var d,e,f,g,h,i,j,k,l;g=b+c.wb();h=a._();f=h.b;e=h.a;d=f+e;if(b==f||f<g&&d>b){k=f<b?b:f;i=d>g?g:d;j=i-k;l=c.xb(k-b,k-b+j);a.bb(k,l)}}
function Dm(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return ym(c,d,e)}
function hq(a,b,c,d){var e,f;f=a.a.d;if(!!f&&uD(f,b.type)){e=ax(a.a,Xh(d,39));cx(a.a,c,d,b);a.b=ax(a.a,Xh(d,39));e&&!a.b&&(!Jp&&(Jp=new Yp),Wp(new vq(a)))}}
function zo(a,b){var c;switch(Rr(),rs(b.type)){case 16:case 32:c=b.relatedTarget||(b.type==UF?b.toElement:b.fromElement);if(!!c&&Ad(a.u,c)){return}}Ge(b,a,a.u)}
function Mh(a,b){var c=new Array(b);if(a==3){for(var d=0;d<b;++d){c[d]={l:0,m:0,h:0}}}else if(a>0&&a<3){var e=a==1?0:false;for(var d=0;d<b;++d){c[d]=e}}return c}
function $v(b,c){var d,e;try{e=b.f.ub(c);b.i=Pz(b.i,c);b.g=b.f.wb();b.j=true;Xv(b);return e}catch(a){a=um(a);if(Zh(a,52)){d=a;throw new Cz(d.e)}else throw tm(a)}}
function Ao(a){if(!a.t){ju();sE(iu,a)&&lu(a)}else if(Zh(a.t,26)){Xh(a.t,26).gb(a)}else if(a.t){throw new zz("This widget's parent does not implement HasWidgets")}}
function hx(a){var b;b=new AA;Rc(b.a,"<div class='listItem editing'><input class='edit' value='");zA(b,En(a));Rc(b.a,"' type='text'><\/div>");return new ln(b.a.a)}
function kz(a,b){var c;b.b=a;if(a==2){c=String.prototype}else{if(a>0){var d=iz(b);if(d){c=d.prototype}else{d=bn[a]=function(){};d.cZ=b;return}}else{return}}c.cZ=b}
function lE(){lE=LE;jE=Oh(qm,PE,1,['Sun','Mon','Tue','Wed','Thu','Fri','Sat']);kE=Oh(qm,PE,1,['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'])}
function Uz(){Uz=LE;Tz=Oh(dm,PE,-1,[48,49,50,51,52,53,54,55,56,57,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122])}
function Mq(a,b,c){var d,e,f,g,h,i;if(b==null){return -1}e=-1;d=2147483647;i=a.k.b;for(h=0;h<i;h++){f=OC(a.k,h);if(Ib(b,f)){g=c-h<0?-(c-h):c-h;if(g<d){e=h;d=g}}}return e}
function vs(a){var b=a.__gwt_disposeEvent;if(b){for(var c=0,d=b.length;c<d;c++){var e=b[c];a.removeEventListener(e.event,e.handler,e.capture);a.__gwt_disposeEvent=null}}}
function Jz(a){var b,c,d;b=Nh(dm,PE,-1,8,1);c=(Uz(),Tz);d=7;if(a>=0){while(a>15){b[d--]=c[a&15];a>>=4}}else{while(d>0){b[d--]=c[a&15];a>>=4}}b[d]=c[a&15];return iA(b,d,8)}
function Yv(a){var b;a.e&&(a.c=true);if(a.n.a!=a){return}b=a.f.wb();if(a.a!=b){a.a=b;Cv(a.n,a.a)}if(a.j){Dv(a.n,a.i,a.f.xb(a.i,a.g));a.j=false}a.i=2147483647;a.g=-2147483648}
function Ge(a,b,c){var d,e,f,g,h;if(De){h=Xh(cf(De,a.type),60);if(h){for(g=h.hb();g.jb();){f=Xh(g.kb(),6);d=f.a.a;e=f.a.b;Ee(f.a,a);Fe(f.a,c);xo(b,f.a);Ee(f.a,d);Fe(f.a,e)}}}}
function Km(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}Im(a,c&4194303);Jm(a,d&4194303);Hm(a,e&1048575);return true}
function Mo(a,b){var c;if(a.p){throw new zz('Composite.initWidget() may only be called once.')}Zh(b,27)&&Xh(b,27);Ao(b);c=(Rr(),b.u);po(a,c);eu(c)&&au(($t(),c),a);a.p=b;Bo(b,a)}
function ao(a){if(!a.b){a.b=Cd($doc,a.a);if(!a.b){throw new wb('Cannot find element with id "'+a.a+'". Perhaps it is not attached to the document body.')}cd(a.b,'id')}return a.b}
function IA(a){var b,c,d,e;d=new vA;b=null;Rc(d.a,BF);c=a.hb();while(c.jb()){b!=null?(Rc(d.a,b),d):(b=FF);e=c.kb();Rc(d.a,e===a?'(this Collection)':mF+e)}Rc(d.a,DF);return d.a.a}
function ld(a,b){var c,d,e;c=a.indexOf(b);while(c!=-1){if(c==0||a.charCodeAt(c-1)==32){d=c+b.length;e=a.length;if(d==e||d<e&&a.charCodeAt(d)==32){break}}c=a.indexOf(b,c+1)}return c}
function vx(a){var b,c,d,e,f,g;d=Pn();if(d){f=new vg;for(b=0;b<a.d.b;b++){e=Xh(OC(a.d,b),39);c=new ih;gh(c,EG,new Ch(e.b));gh(c,FG,(Gg(),e.a?Fg:Eg));g=sg(f,b);tg(f,b,c)}Nn(d,ug(f))}}
function jB(h,a,b){var c=h.a[b];if(c){for(var d=0,e=c.length;d<e;++d){var f=c[d];var g=f.Fb();if(h.Eb(a,g)){c.length==1?delete h.a[b]:c.splice(d,1);--h.d;return f.Gb()}}}return null}
function Lc(b){var c=mF;try{for(var d in b){if(d!='name'&&d!='message'&&d!='toString'){try{var e=d!='__gwt$exception'?b[d]:'<skipped>';c+='\n '+d+jF+e}catch(a){}}}}catch(a){}return c}
function Bo(a,b){var c;c=a.t;if(!b){try{!!c&&c.U()&&a.X()}finally{a.t=null}}else{if(c){throw new zz('Cannot set a new parent without first clearing the old parent')}a.t=b;b.U()&&a.V()}}
function xp(a,b,c){var d,e;e=wp(a,b,Rq(a.a.n).b);a.a.i=a.a.i||c;a.b=a.a.i;a.a.j=true;Xo(a.a,e);a.a.j=false;d=iq(a.a);if(d){$o(a.a,d,true);a.a.i&&lq(a.a)}xo(a.a,new Hp(nD(Nq(a.a.n).k)))}
function yp(a,b,c,d){var e,f;f=wp(a,b,Rq(a.a.n).b+c);a.a.i=a.a.i||d;a.b=a.a.i;a.a.j=true;Yo(a.a,c,f);a.a.j=false;e=iq(a.a);if(e){$o(a.a,e,true);a.a.i&&lq(a.a)}xo(a.a,new Hp(nD(Nq(a.a.n).k)))}
function Df(a,b,c){if(!b){throw new Sz('Cannot add a handler with a null type')}if(!c){throw new Sz('Cannot add a null handler')}a.b>0?Cf(a,new Tw(a,b,c)):Ef(a,b,c);return new Rw(a,b,c)}
function fn(a){return $stats({moduleName:$moduleName,sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date).getTime(),type:'onModuleLoadStart',className:a})}
function yh(b){rh();var c;if(b==null){throw new Rz}if(b.length==0){throw new wz('empty argument')}try{return xh(b,true)}catch(a){a=um(a);if(Zh(a,2)){c=a;throw new Og(c)}else throw tm(a)}}
function ot(b,c){mt();var d,e,f,g;d=null;for(g=b.hb();g.jb();){f=Xh(g.kb(),32);try{c.ib(f)}catch(a){a=um(a);if(Zh(a,57)){e=a;!d&&(d=new uE);rE(d,e)}else throw tm(a)}}if(d){throw new nt(d)}}
function Sb(b){Qb();var c=b.replace(/[\xad\u0600-\u0603\u06dd\u070f\u17b4\u17b5\u200b-\u200f\u2028-\u202e\u2060-\u2064\u206a-\u206f\ufeff\ufff9-\ufffb]/g,function(a){return Rb(a)});return c}
function yc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].C()&&(c=xc(c,g)):g[0].D()}catch(a){a=um(a);if(Zh(a,57)){d=a;gc(Zh(d,2)?Xh(d,2).B():d)}else throw tm(a)}}return c}
function dd(a,b){var c,d,e,f,g;b=nd(b);g=a.className;e=ld(g,b);if(e!=-1){c=gA(fA(g,0,e));d=gA(eA(g,e+b.length));c.length==0?(f=d):d.length==0?(f=c):(f=c+rF+d);fd(a,f);return true}return false}
function Sp(a){!$wnd.__gwt_CellBasedWidgetImplLoadListeners&&($wnd.__gwt_CellBasedWidgetImplLoadListeners=new Array);$wnd.__gwt_CellBasedWidgetImplLoadListeners[a]=iF(function(){_p($wnd.event)})}
function yf(b,c){var d,e;!c.g||(c.g=false,c.i=null);e=c.i;Ce(c,b.b);try{Ff(b.a,c)}catch(a){a=um(a);if(Zh(a,38)){d=a;throw new $f(d.a)}else throw tm(a)}finally{e==null?(c.g=true,c.i=null):(c.i=e)}}
function sC(a,b,c){this.c=a;this.a=b;this.b=c-b;if(b>c){throw new wz(LG+b+' > toIndex: '+c)}if(b<0){throw new Cz(LG+b+' < 0')}if(c>a.wb()){throw new Cz('toIndex: '+c+' > wrapped.size() '+a.wb())}}
function Bb(a){var b,c;if(a.c==null){b=a.b===zb?null:a.b;a.d=b==null?kF:$h(b)?Eb(Yh(b)):Zh(b,1)?lF:(c=b,_h(c)?c.cZ:li).c;a.a=a.a+jF+($h(b)?Db(Yh(b)):b+mF);a.c=nF+a.d+') '+($h(b)?Lc(Yh(b)):mF)+a.a}}
function lp(a,b,c){var d,e,f,g,h;d=a.childNodes.length;h=null;c<d&&(h=a.childNodes[c]);e=b.childNodes.length;for(f=0;f<e;f++){if(!h){Uc(a,b.childNodes[0])}else{g=rd(h);Zc(a,b.childNodes[0],h);h=g}}}
function fp(a){var b;Mo(this,a);this.n=new _q(this,new Cp(this));b=new uE;rE(b,XF);rE(b,YF);rE(b,ZF);rE(b,vF);rE(b,uF);rE(b,$F);Kp((!Jp&&(Jp=new Yp),Jp),this,b);Uo(this,new Ov);ap(this,new sp(this))}
function Kp(a,b,c){var d,e,f,g;if(!c){return}d=0;for(g=c.hb();g.jb();){f=Xh(g.kb(),1);e=rs((Rr(),f));if(!(e<0)){e=Xp(a,b,f);e>0&&(d|=e)}}d>0&&(b.r==-1?Vr((Rr(),b.u),d|(b.u.__eventBits||0)):(b.r|=d))}
function Gq(a,b,c){var d;d=new AA;Rc(d.a,'<div onclick="" __idx="');zA(d,En(mF+a));Rc(d.a,'" class="');zA(d,En(b));Rc(d.a,'" style="outline:none;" >');zA(d,c.a);Rc(d.a,'<\/div>');return new ln(d.a.a)}
function yv(){var a=-1;if(navigator.appName=='Microsoft Internet Explorer'){var b=navigator.userAgent;var c=new RegExp('MSIE ([0-9]{1,}[.0-9]{0,})');c.exec(b)!=null&&(a=parseFloat(RegExp.$1))}return a}
function pA(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)))|0;c+=4}while(c<d){b=b*31+_z(a,c++)}return b|0}
function Ph(a,b,c){if(c!=null){if(a.qI>0&&!Wh(c,a.qI)){throw new Vy}else if(a.qI==-1&&(c.tM==LE||Vh(c,1))){throw new Vy}else if(a.qI<-1&&!(c.tM!=LE&&!Vh(c,1))&&!Wh(c,-a.qI)){throw new Vy}}return a[b]=c}
function lr(a){var b,c;jr.call(this,a.f);this.b=false;this.c=new UC;this.d=a.d;this.e=a.e;this.f=a.f;this.g=a.g;this.i=a.i;this.j=a.j;this.o=a.o;this.p=a.p;c=a.k.b;for(b=0;b<c;b++){LC(this.k,OC(a.k,b))}}
function ud(a,b){var c,d;if(b.indexOf(qF)!=-1){c=(!a.__gwt_container&&(a.__gwt_container=a.createElement(sF)),a.__gwt_container);hd(c,tF+b+'/>');d=qd(c);c.removeChild(d);return d}return a.createElement(b)}
function fB(j,a,b,c){var d=j.a[c];if(d){for(var e=0,f=d.length;e<f;++e){var g=d[e];var h=g.Fb();if(j.Eb(a,h)){var i=g.Gb();g.Hb(b);return i}}}else{d=j.a[c]=[]}var g=new EE(a,b);d.push(g);++j.d;return null}
function fy(){this.n=new qq(new gx);Mo(this,py(new qy(this)));bp(this.n,(zr(),xr));gd(this.c,'main');gd((Rr(),this.a.u),'clear-completed');gd(this.j.u,'new-todo');gd(this.k,'footer');gd(this.o,'toggle-all')}
function Tb(b){Qb();var c=b.replace(/[\x00-\x1f\xad\u0600-\u0603\u06dd\u070f\u17b4\u17b5\u200b-\u200f\u2028-\u202e\u2060-\u2064\u206a-\u206f\ufeff\ufff9-\ufffb"\\]/g,function(a){return Rb(a)});return pF+c+pF}
function Gc(a){var b,c,d;d=mF;a=gA(a);b=a.indexOf(nF);c=a.indexOf(oF)==0?8:0;if(b==-1){b=cA(a,String.fromCharCode(64));c=a.indexOf('function ')==0?9:0}b!=-1&&(d=gA(fA(a,c,b)));return d.length>0?d:'anonymous'}
function Yt(a){this.a=(Rr(),ud($doc,'a'));if(!a){oo(this,this.a)}else{po(this,a);Sr(this.u,this.a)}this.r==-1?Vr(this.u,1|(this.u.__eventBits||0)):(this.r|=1);fd(this.u,'gwt-Hyperlink');this.b=new Pt(this.a)}
function Ad(a,b){if(a.nodeType!=1&&a.nodeType!=9){return a==b}if(b.nodeType!=1){b=b.parentNode;if(!b){return false}}if(a.nodeType==9){return a===b||a.body&&a.body.contains(b)}else{return a===b||a.contains(b)}}
function Vp(a,b){var c,d,e;if(a.b&&!!b){e=$moduleName;d='__gwt_CellBasedWidgetImplLoadListeners["'+e+'"]();';c=b.a;c=dA(c,'(<img)([\\s/>])',"<img onload='"+d+"' onerror='"+d+"'$2");b=(Dn(),new tn(c))}return b}
function Qm(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return {l:c&4194303,m:d&4194303,h:e&1048575}}
function Sm(a,b){var c,d,e,f;b&=63;c=a.h&1048575;if(b<22){f=c>>>b;e=a.m>>b|c<<22-b;d=a.l>>b|a.m<<22-b}else if(b<44){f=0;e=c>>>b-22;d=a.m>>b-22|a.h<<44-b}else{f=0;e=0;d=c>>>b-44}return {l:d&4194303,m:e&4194303,h:f&1048575}}
function re(a){var b,c,d,e,f;d=ue();if(d<30){return qe(a)}else{f=2147483647;e=-1;for(b=0;b<d;b++){c=ne[b];c==0&&(c=ne[b]=$doc.styleSheets[b].cssText.length);if(c<=f){f=c;e=b}}ne[e]+=a.length;return pe(e,a,true)}}
function kv(a,b,c){var d,e,f;if(c<0||c>a.c){throw new Bz}if(a.c==a.a.length){f=Nh(lm,PE,32,a.a.length*2,0);for(d=0;d<a.a.length;++d){Ph(f,d,a.a[d])}a.a=f}++a.c;for(e=a.c-1;e>c;--e){Ph(a.a,e,a.a[e-1])}Ph(a.a,c,b)}
function cn(a,b,c){var d=bn[a];if(d&&!d.cZ){_=d.prototype}else{!d&&(d=bn[a]=function(){});_=d.prototype=b<0?{}:dn(b);_.cM=c}for(var e=3;e<arguments.length;++e){arguments[e].prototype=_}if(d.cZ){_.cZ=d.cZ;d.cZ=null}}
function Up(a,b,c){var d,e,f;f=c.type.toLowerCase();if(aA(XF,f)||aA(YF,f)||aA(aG,f)){d=c.srcElement;if(md(d)){e=d;e!=(Rr(),b.u)&&ws(e,null)}}!!Np&&aA(aG,f)&&(Pp=$p(Np));!!Np&&!Op&&sE(a.a,f)&&tc((mc(),lc),new dq(b))}
function uh(a){if(!a){return Rg(),Qg}var b=a.valueOf?a.valueOf():a;if(b!==a){var c=qh[typeof b];return c?c(b):Ah(typeof b)}else if(a instanceof Array||a instanceof $wnd.Array){return new wg(a)}else{return new jh(a)}}
function nq(a,b,c,d){var e,f,g,h,i,j;Oq(a.n)+Rq(a.n).b;i=c.wb();g=d+i;for(h=d;h<g;h++){j=c.pb(h-d);f=new AA;Rc(f.a,h%2==0?'GMY2FQLAB':'GMY2FQLCB');e=new rn;new jb(h,a.n);ex(a.a,j,e);qn(b,Gq(h,f.a.a,new tn(e.a.a.a)))}}
function Zf(a){var b,c,d,e,f;c=a.wb();if(c==0){return null}b=new BA(c==1?'Exception caught: ':c+' exceptions caught: ');d=true;for(f=a.hb();f.jb();){e=Xh(f.kb(),57);d?(d=false):(Rc(b.a,'; '),b);zA(b,e.A())}return b.a.a}
function Yp(){this.c=new uE;rE(this.c,eG);rE(this.c,fG);rE(this.c,gG);rE(this.c,'option');rE(this.c,'button');rE(this.c,'label');if(!Qp){Qp=new uE;rE(Qp,eG);rE(Qp,fG);rE(Qp,gG)}this.a=new uE;rE(this.a,hG);rE(this.a,iG)}
function so(a,b,c){if(!a){throw new wb('Null widget handle. If you are creating a composite, ensure that initWidget() has been called.')}b=gA(b);if(b.length==0){throw new wz('Style names cannot be empty')}c?_c(a,b):dd(a,b)}
function tx(b){var c,d,e,f,g,h,i;g=Pn();if(g){try{f=Sn(g.a,QF);i=(rh(),yh(f)).M();for(d=0;d<i.a.length;d++){e=sg(i,d).O();h=eh(e,EG).P().a;c=eh(e,FG).N().a;LC(b.d,new nx(h,c))}}catch(a){a=um(a);if(!Zh(a,51))throw tm(a)}}xx(b)}
function En(a){Dn();a.indexOf(MF)!=-1&&(a=gn(yn,a,'&amp;'));a.indexOf(tF)!=-1&&(a=gn(An,a,'&lt;'));a.indexOf(OF)!=-1&&(a=gn(zn,a,'&gt;'));a.indexOf(pF)!=-1&&(a=gn(Bn,a,'&quot;'));a.indexOf(PF)!=-1&&(a=gn(Cn,a,'&#39;'));return a}
function Hz(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Rt(a,b,c){var d,e,f;if(c==(Rr(),b.u)){return}Ao(b);f=null;d=new sv(a.b);while(d.b<d.c.c){e=qv(d);if(Ad(c,e.u)){if(e.u==c){f=e;break}rv(d)}}hv(a.b,b);if(!f){Zc(c.parentNode,b.u,c)}else{Xc(c.parentNode,b.u,c);ct(a,f)}Bo(b,a)}
function yo(a){var b;if(a.U()){throw new zz("Should only call onAttach when the widget is detached from the browser's document")}a.q=true;Rr();ws(a.u,a);b=a.r;a.r=-1;b>0&&(a.r==-1?Vr(a.u,b|(a.u.__eventBits||0)):(a.r|=b));a.S();a.Y()}
function Bv(a,b){var c;if(!b){throw new wz('display cannot be null')}else if(sE(a.b,b)){throw new zz('The specified display has already been added to this adapter.')}rE(a.b,b);c=Vo(b,new Gv(a,b));eB(a.e,b,c);a.c>=0&&cp(b,a.c,a.d);Rv(a,b)}
function ix(a,b,c,d){var e;e=new AA;Rc(e.a,"<div class='");zA(e,En(c));Rc(e.a,"' data-timestamp='");zA(e,En(d));Rc(e.a,"'>");zA(e,a.a);Rc(e.a,' <label>');zA(e,b.a);Rc(e.a,"<\/label><button class='destroy'><\/a><\/div>");return new ln(e.a.a)}
function Kt(a){if(a.c){Fd(a.a.style,uG,tG);to(a.a,true);to(a.b,false);Fd(a.b.style,uG,tG)}else{to(a.a,false);Fd(a.a.style,uG,tG);Fd(a.b.style,uG,tG);to(a.b,true)}Fd(a.a.style,wG,xG);Fd(a.b.style,wG,xG);a.a=null;a.b=null;qo(a.d,false);a.d=null}
function Ic(i){var a={};var b=[];var c=arguments.callee.caller.caller;while(c){var d=i.F(c.toString());b.push(d);var e=qF+d;var f=a[e];if(f){var g,h;for(g=0,h=f.length;g<h;g++){if(f[g]===c){return b}}}(f||(a[e]=[])).push(c);c=c.caller}return b}
function ge(){fe();var a,b,c;c=null;if(ee.length!=0){a=ee.join(mF);b=te((me(),a));!ee&&(c=b);Nb(ee,0)}if(ce.length!=0){a=ce.join(mF);b=re((me(),a));!ce&&(c=b);Nb(ce,0)}if(de.length!=0){a=de.join(mF);b=se((me(),a));!de&&(c=b);Nb(de,0)}be=false;return c}
function Ps(g){var d=mF;var e=$wnd.location.hash;e.length>0&&(d=g.db(e.substring(1)));Vs(d);var f=g;f.b=$wnd.onhashchange;$wnd.onhashchange=iF(function(){var a=mF,b=$wnd.location.hash;b.length>0&&(a=f.db(b.substring(1)));f.fb(a);var c=f.b;c&&c()});return true}
function Gm(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return Iz(c)}if(b==0&&d!=0&&c==0){return Iz(d)+22}if(b!=0&&d==0&&c==0){return Iz(b)+44}return -1}
function Lt(a,b,c){var d,e,f,g;$(a);d=(Rr(),sd(c.u));e=Fs(sd(d),d);if(!b){to(d,true);to(c.u,true);return}a.d=b;f=sd(b.u);g=Fs(sd(f),f);if(e>g){a.a=f;a.b=d;a.c=false}else{a.a=d;a.b=f;a.c=true}to(a.a,a.c);to(a.b,!a.c);a.a=null;a.b=null;qo(a.d,false);a.d=null;to(c.u,true)}
function Rm(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&524288)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?1048575:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?1048575:0;f=d?4194303:0;e=c>>b-44}return {l:e&4194303,m:f&4194303,h:g&1048575}}
function sc(a){var b,c,d,e,f,g,h;f=a.length;if(f==0){return null}b=false;c=new lb;while(mb()-c.a<100){d=false;for(e=0;e<f;e++){h=a[e];if(!h){continue}d=true;if(!h[0].C()){a[e]=null;b=true}}if(!d){break}}if(b){g=[];for(e=0;e<f;e++){!!a[e]&&Kb(g,a[e])}return g.length==0?null:g}else{return a}}
function Ft(a,b){var c,d,e;c=(d=(Rr(),ud($doc,sF)),Fd(d.style,sG,tG),Fd(d.style,uG,vG),Fd(d.style,'padding',vG),Fd(d.style,'margin',vG),d);Sr(a.u,c);_s(a,b,c);to(c,false);Fd(c.style,uG,tG);e=b.u;aA(e.style[sG],mF)&&(b.u.style[sG]=tG,undefined);aA(e.style[uG],mF)&&(b.u.style[uG]=tG,undefined);to(b.u,false)}
function du(){var c=function(){};c.prototype={className:mF,clientHeight:0,clientWidth:0,dir:mF,getAttribute:function(a,b){return this[a]},href:mF,id:mF,lang:mF,nodeType:1,removeAttribute:function(a,b){this[a]=undefined},setAttribute:function(a,b){this[a]=b},src:mF,style:{},title:mF};$wnd.GwtPotentialElementShim=c}
function qz(a){var b,c,d,e,f;if(a==null){throw new Wz(kF)}d=a.length;e=d>0&&(a.charCodeAt(0)==45||a.charCodeAt(0)==43)?1:0;for(b=e;b<d;b++){if(cz(a.charCodeAt(b))==-1){throw new Wz(JG+a+pF)}}f=parseInt(a,10);c=f<-2147483648;if(isNaN(f)){throw new Wz(JG+a+pF)}else if(c||f>2147483647){throw new Wz(JG+a+pF)}return f}
function rq(a){var b;ep.call(this,ud($doc,sF));Dn();new tn(mF);this.d=new yu;this.e=new yu;this.f=new Ht;this.a=a;this.g=(Fq(),zq);Cq(this.g);so((Rr(),this.u),'GMY2FQLEB',true);this.c=ud($doc,sF);b=this.u;Uc(b,this.c);Uc(b,no(this.f));this.f.$(this);Ft(this.f,this.d);Ft(this.f,this.e);Kp((!Jp&&(Jp=new Yp),Jp),this,a.d)}
function zx(a){var b;this.f=new Cx(this);this.d=new UC;this.b=new Sv;this.c=(Ox(),Mx);this.e=a;tx(this);b=(Zr(),Yr?Ms==null?mF:Ms:mF);this.c=aA(b,wF)?Lx:aA(b,xF)?Nx:Mx;_x(a,this.f);cy(a,this.b);dy(a,this.c);yx(this);$r(new Ix(this));this.a=(Cy(),Cy(),By);Tf(this.a,(Ny(),My),new Ex(this));Tf(this.a,(Gy(),Fy),new Gx(this))}
function Ff(b,c){var d,e,f,g,h;if(!c){throw new Sz('Cannot fire null event')}try{++b.b;g=If(b,c.H());d=null;h=b.c?g.tb(g.wb()):g.sb();while(b.c?h.zb():h.jb()){f=b.c?h.Ab():h.kb();try{c.G(Xh(f,11))}catch(a){a=um(a);if(Zh(a,57)){e=a;!d&&(d=new uE);rE(d,e)}else throw tm(a)}}if(d){throw new Xf(d)}}finally{--b.b;b.b==0&&Kf(b)}}
function Nm(a){var b,c,d,e,f;if(isNaN(a)){return _m(),$m}if(a<-9223372036854775808){return _m(),Ym}if(a>=9223372036854775807){return _m(),Xm}e=false;if(a<0){e=true;a=-a}d=0;if(a>=17592186044416){d=bi(a/17592186044416);a-=d*17592186044416}c=0;if(a>=4194304){c=bi(a/4194304);a-=c*4194304}b=bi(a);f=ym(b,c,d);e&&Em(f);return f}
function Cq(a){if(!a.a){a.a=true;fe();he('.GMY2FQLAB,.GMY2FQLCB{cursor:pointer;zoom:1;}.GMY2FQLBB{background:#ffc;}.GMY2FQLDB{height:'+(Eq(),yq.a)+'px;overflow:hidden;background:url("'+yq.d.a+'") -'+yq.b+'px -'+yq.c+'px  repeat-x;background-color:#628cd5;color:white;height:auto;overflow:visible;}');return true}return false}
function Vm(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return KF}if(a.h==524288&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Vm(Pm(a))}c=a;d=mF;while(!(c.l==0&&c.m==0&&c.h==0)){e=Om(1000000000);c=zm(c,e,true);b=mF+Um(vm);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b=KF+b}}d=b+d}return d}
function kq(a,b){var c,d,e,f,g,h,i,j,k,l,m;e=b.srcElement;if(!md(e)){return}l=b.srcElement;h=mF;c=l;while(!!c&&(h=xd(c,'__idx')).length==0){c=sd(c)}if(h.length>0){f=b.type;aA(uF,f);g=qz(h);i=g-Rq(a.n).b;if(!(i>=0&&i<Nq(a.n).k.b)){return}j=(zr(),wr)==a.n.d;m=(Wo(a,i),Pq(a.n,i));d=new jb(g,a.n);k=Lv(a,b,a,d,a.b,j);k.c||hq(a,b,c,m)}}
function xh(b,c){var d;if(c&&(Qb(),Pb)){try{d=JSON.parse(b)}catch(a){return zh(HF+a)}}else{if(c){if(!(Qb(),!/[^,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t]/.test(b.replace(/"(\\.|[^"\\])*"/g,mF)))){return zh('Illegal character in JSON string')}}b=Sb(b);try{d=eval(nF+b+IF)}catch(a){return zh(HF+a)}}var e=qh[typeof d];return e?e(d):Ah(typeof d)}
function Kq(a,b,c){var d,e,f,g,h,i,j,k,l,m,n;dr(a);l=-1;h=-1;m=-1;i=-1;g=0;for(e=0;e<a.length;e++){f=a[e];if(f<b||f>=c){continue}else if(l==-1){l=f;h=f}else if(m==-1){g=f-h;m=f;i=f}else{d=f-i;if(d>g){h=i;m=f;i=f;g=d}else{i=f}}}h+=1;i+=1;if(m==h){h=i;m=-1;i=-1}n=new UC;if(l!=-1){j=h-l;LC(n,new Ew(l,j))}if(m!=-1){k=i-m;LC(n,new Ew(m,k))}return n}
function dx(a,b,c){var d,e,f;if(a.b==b){d=hx(b.b);zA(c.a,d.a)}else{d=ix(b.a?(e=new AA,Rc(e.a,"<input class='toggle' type='checkbox' checked>"),new ln(e.a.a)):(f=new AA,Rc(f.a,"<input class='toggle' type='checkbox'>"),new ln(f.a.a)),(Dn(),new tn(En(b.b))),b.a?'listItem view completed':'listItem view',mF+Vm(Nm((new eE).a.getTime())));zA(c.a,d.a)}}
function Xp(a,b,c){var d,e,f,g;if(aA(aG,c)||aA(XF,c)||aA(YF,c)){!Mp&&Rp();e=0;d=(Rr(),b.u);if(!aA(TF,xd(d,bG))){ed(d,bG,TF);d.attachEvent('onfocusin',Mp);d.attachEvent('onfocusout',Mp);for(g=yC(TA(a.a.a));gC(g.a.a);){f=Xh(EC(g),1);e|=rs(f)}}return e}else if(aA(cG,c)||aA(dG,c)){if(!a.b){a.b=true;Sp($moduleName)}return -1}else{return rs((Rr(),c))}}
function Yq(a,b,c){var d,e,f,g,h,i,j,k,l,m,n,o;o=c.wb();n=b+o;k=(!a.e?a.i:a.e).g;j=(!a.e?a.i:a.e).g+(!a.e?a.i:a.e).f;e=b>k?b:k;d=n<j?n:j;if(b!=k&&e>=d){return}l=Lq(a);f=Oz(0,e-k-(!a.e?a.i:a.e).k.b);for(h=0;h<f;h++){LC(l.k,null)}for(i=e;i<d;i++){m=c.pb(i-b);g=i-k;g<(!a.e?a.i:a.e).k.b?SC(l.k,g,m):LC(l.k,m)}LC(l.c,new Ew(e-f,d-(e-f)));n>(!a.e?a.i:a.e).i&&Xq(a,n,(!a.e?a.i:a.e).j)}
function qy(a){this.v=a;this.w=(new ty,xy(),sy);vy(this.w);this.f=Bd($doc);this.a=Bd($doc);this.c=Bd($doc);this.g=Bd($doc);this.i=Bd($doc);this.k=Bd($doc);this.n=Bd($doc);this.o=Bd($doc);this.p=Bd($doc);this.r=Bd($doc);this.t=Bd($doc);this.d=Bd($doc);this.b=new bo(this.a);this.j=new bo(this.i);this.q=new bo(this.p);this.s=new bo(this.r);this.u=new bo(this.t);this.e=new bo(this.d)}
function Cm(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=Fm(b)-Fm(a);g=Qm(b,j);i=ym(0,0,0);while(j>=0){h=Km(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;Hm(g,l>>>1);g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&Em(i);if(f){if(d){vm=Pm(a);e&&(vm=Tm(vm,(_m(),Zm)))}else{vm=ym(a.l,a.m,a.h)}}return i}
function _p(a){var b,c,d,e,f,g,h;c=a.srcElement;if(!md(c)){return}f=c;b=f;d=(Rr(),us(f));while(!!b&&!d){b=sd(b);d=!b?null:us(b)}if(!Zh(d,32)){return}h=Xh(d,32);if(f==h.u){return}g=a.type;if(aA('focusin',g)){e=yd(f).toLowerCase();if(sE(Qp,e)){Np=f;Pp=$p(f);Op=!aA(eG,e)&&!aq(f)}Zp(h,f,2048,null)}else if(aA('focusout',g)){bq(h);Np=null;vd($doc,XF);Zp(h,f,4096,null)}else (aA(cG,g)||aA(dG,g))&&Tr(a,h.u,d)}
function rm(){var a,b;en()&&fn('com.google.gwt.useragent.client.UserAgentAsserter');a=zv();aA(JF,a)||($wnd.alert('ERROR: Possible problem with your *.gwt.xml module file.\nThe compile time user.agent value (ie8) does not match the runtime user.agent value ('+a+'). Expect more errors.\n'),undefined);en()&&fn('com.google.gwt.user.client.DocumentModeAsserter');Wr();en()&&fn('com.todo.client.GwtToDo');b=new fy;new zx(b);gt((ju(),nu()),b)}
function bx(a,b,c,d){var e,f,g,h,i,j;j=d.type;if(a.b==c){if(aA(vF,j)){h=pd(d);if(h==13){_w(a,b,c);a.b=null;fx(a,b,c)}h==27&&(a.b=null,fx(a,b,c))}if(aA(YF,j)&&!a.a){_w(a,b,c);a.b=null;fx(a,b,c)}}else{if(aA(kG,j)){a.b=c;fx(a,b,c);a.a=true;g=Wc(b.firstChild);ad(g);a.a=false}if(aA(uF,j)){f=d.srcElement;e=f;i=yd(e);if(aA(i,CG)){g=e;kx(c,Dd(g));vf(a.c,new Py(c));Dd(g)?_c(b.firstChild,DG):dd(b.firstChild,DG)}else aA(i,'BUTTON')&&vf(a.c,new Iy(c))}}}
function zv(){var b=navigator.userAgent.toLowerCase();var c=function(a){return parseInt(a[1])*1000+parseInt(a[2])};if(function(){return b.indexOf('webkit')!=-1}())return 'safari';if(function(){return b.indexOf(zG)!=-1&&$doc.documentMode>=10}())return 'ie10';if(function(){return b.indexOf(zG)!=-1&&$doc.documentMode>=9}())return 'ie9';if(function(){return b.indexOf(zG)!=-1&&$doc.documentMode>=8}())return JF;if(function(){return b.indexOf('gecko')!=-1}())return 'gecko1_8';return 'unknown'}
function Zq(a,b,c){var d,e,f,g,h,i,j,k,l,m;m=b.b;g=b.a;if(m<0){throw new wz('Range start cannot be less than 0')}if(g<0){throw new wz('Range length cannot be less than 0')}j=(!a.e?a.i:a.e).g;h=(!a.e?a.i:a.e).f;k=j!=m;if(k){l=Lq(a);if(!c){if(m>j){f=m-j;if((!a.e?a.i:a.e).k.b>f){for(e=0;e<f;e++){QC(l.k,0)}}else{NC(l.k)}}else{d=j-m;if((!a.e?a.i:a.e).k.b>0&&d<h){for(e=0;e<d;e++){KC(l.k,0,null)}LC(l.c,new Ew(m,m+d-m))}else{NC(l.k)}}}l.g=m}i=h!=g;i&&(Lq(a).f=g);c&&NC(Lq(a).k);$q(a);(k||i)&&Nw(a.a,new Ew((!a.e?a.i:a.e).g,(!a.e?a.i:a.e).f))}
function Vq(a,b,c,d){var e,f,g,h,i,j,k,l;if((zr(),xr)==a.d){return}a.c.a&&(b=Oz(0,Pz(b,(!a.e?a.i:a.e).k.b-1)));Lq(a).p=true;if(!d&&(xr==a.d?-1:(!a.e?a.i:a.e).d)==b&&(xr==a.d?null:(!a.e?a.i:a.e).e)!=null){return}i=(!a.e?a.i:a.e).g;h=(!a.e?a.i:a.e).f;k=(!a.e?a.i:a.e).i;e=i+b;e>=k&&(!a.e?a.i:a.e).j&&(e=k-1);b=(0>e?0:e)-i;a.c.a&&(b=0>(b<h-1?b:h-1)?0:b<h-1?b:h-1);g=i;f=h;j=Lq(a);j.d=0;j.e=null;j.a=true;if(b>=0&&b<h){j.d=b;j.e=b<j.k.b?ir(Lq(a),b):null;j.b=c;return}else if((rr(),or)==a.c){while(b<0){l=h<g?h:g;g-=l;b+=l}while(b>=h){g+=h;b-=h}}else if(qr==a.c){while(b<0){l=30<g?30:g;f+=l;g-=l;b+=l}while(b>=f){f+=30}if((!a.e?a.i:a.e).j){f=f<k-g?f:k-g;b>=k&&(b=k-1)}}if(g!=i||f!=h){j.d=b;Zq(a,new Ew(g,f),false)}}
function zm(a,b,c){var d,e,f,g,h,i,j,k;if(b.l==0&&b.m==0&&b.h==0){throw new Ty}if(a.l==0&&a.m==0&&a.h==0){c&&(vm=ym(0,0,0));return ym(0,0,0)}if(b.h==524288&&b.m==0&&b.l==0){return Am(a,c)}i=false;if(b.h>>19!=0){b=Pm(b);i=true}g=Gm(b);f=false;e=false;d=false;if(a.h==524288&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=xm((_m(),Xm));d=true;i=!i}else{h=Rm(a,g);i&&Em(h);c&&(vm=ym(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Pm(a);d=true;i=!i}if(g!=-1){return Bm(a,g,i,f,c)}if(!(j=a.h>>19,k=b.h>>19,j==0?k!=0||a.h>b.h||a.h==b.h&&a.m>b.m||a.h==b.h&&a.m==b.m&&a.l>=b.l:!(k==0||a.h<b.h||a.h==b.h&&a.m<b.m||a.h==b.h&&a.m==b.m&&a.l<b.l))){c&&(f?(vm=Pm(a)):(vm=ym(a.l,a.m,a.h)));return ym(0,0,0)}return Cm(d?a:ym(a.l,a.m,a.h),b,i,f,e,c)}
function rs(a){switch(a){case YF:return 4096;case aG:return 1024;case uF:return 1;case kG:return 2;case XF:return 2048;case ZF:return 128;case 'keypress':return 256;case vF:return 512;case cG:return 32768;case 'losecapture':return 8192;case $F:return 4;case 'mousemove':return 64;case UF:return 32;case 'mouseover':return 16;case hG:return 8;case 'scroll':return 16384;case dG:return 65536;case 'DOMMouseScroll':case iG:return 131072;case 'contextmenu':return 262144;case 'paste':return 524288;case 'touchstart':return 1048576;case 'touchmove':return 2097152;case 'touchend':return 4194304;case 'touchcancel':return 8388608;case 'gesturestart':return 16777216;case 'gesturechange':return 33554432;case 'gestureend':return 67108864;default:return -1;}}
function Is(a,b){var c=(a.__eventBits||0)^b;a.__eventBits=b;if(!c)return;c&1&&(a.onclick=b&1?Cs:null);c&3&&(a.ondblclick=b&3?Bs:null);c&4&&(a.onmousedown=b&4?Cs:null);c&8&&(a.onmouseup=b&8?Cs:null);c&16&&(a.onmouseover=b&16?Cs:null);c&32&&(a.onmouseout=b&32?Cs:null);c&64&&(a.onmousemove=b&64?Cs:null);c&128&&(a.onkeydown=b&128?Cs:null);c&256&&(a.onkeypress=b&256?Cs:null);c&512&&(a.onkeyup=b&512?Cs:null);c&1024&&(a.onchange=b&1024?Cs:null);c&2048&&(a.onfocus=b&2048?Cs:null);c&4096&&(a.onblur=b&4096?Cs:null);c&8192&&(a.onlosecapture=b&8192?Cs:null);c&16384&&(a.onscroll=b&16384?Cs:null);c&32768&&(a.nodeName=='IFRAME'?b&32768?a.attachEvent(pG,Ds):a.detachEvent(pG,Ds):(a.onload=b&32768?Es:null));c&65536&&(a.onerror=b&65536?Cs:null);c&131072&&(a.onmousewheel=b&131072?Cs:null);c&262144&&(a.oncontextmenu=b&262144?Cs:null);c&524288&&(a.onpaste=b&524288?Cs:null)}
function py(a){var b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r;c=new St(zy(a.a,a.c,a.g,a.i,a.k,a.n,a.o,a.p,a.r,a.t,a.d).a);b=eo((Rr(),c.u));ao(a.b);d=ao(new bo(a.c));a.v.c=d;e=ao(new bo(a.g));a.v.o=e;ao(a.j);f=ao(new bo(a.k));a.v.k=f;g=ao(new bo(a.n));a.v.d=g;h=ao(new bo(a.o));a.v.e=h;ao(a.q);ao(a.s);ao(a.u);ao(a.e);b.b?Xc(b.b,b.a,b.c):go(b.a);Rt(c,(i=new Zw,ed(i.u,'placeholder','What needs to be done?'),a.v.j=i,i),ao(a.b));Rt(c,a.v.n,ao(a.j));Rt(c,(j=new Xt,Vt(j,(p=new AA,Rc(p.a,'All'),new ln(p.a.a)).a),fd(j.u,HG),Wt(j,'/'),a.v.g=j,j),ao(a.q));Rt(c,(k=new Xt,Vt(k,(q=new AA,Rc(q.a,'Active'),new ln(q.a.a)).a),fd(k.u,HG),Wt(k,wF),a.v.f=k,k),ao(a.s));Rt(c,(l=new Xt,Vt(l,(r=new AA,Rc(r.a,'Completed'),new ln(r.a.a)).a),fd(l.u,HG),Wt(l,xF),a.v.i=l,l),ao(a.u));Rt(c,(m=new Ct,At(m,yy(a.f).a),n=eo(m.u),o=ao(new bo(a.f)),a.v.b=o,n.b?Xc(n.b,n.a,n.c):go(n.a),a.v.a=m,m),ao(a.e));return c}
function Wr(){var a,b,c;b=$doc.compatMode;a=Oh(qm,PE,1,[jG]);for(c=0;c<a.length;c++){if(aA(a[c],b)){return}}a.length==1&&aA(jG,a[0])&&aA('BackCompat',b)?"GWT no longer supports Quirks Mode (document.compatMode=' BackCompat').<br>Make sure your application's host HTML page has a Standards Mode (document.compatMode=' CSS1Compat') doctype,<br>e.g. by using &lt;!doctype html&gt; at the start of your application's HTML page.<br><br>To continue using this unsupported rendering mode and risk layout problems, suppress this message by adding<br>the following line to your*.gwt.xml module file:<br>&nbsp;&nbsp;&lt;extend-configuration-property name=\"document.compatMode\" value=\""+b+'"/&gt;':"Your *.gwt.xml module configuration prohibits the use of the current doucment rendering mode (document.compatMode=' "+b+"').<br>Modify your application's host HTML page doctype, or update your custom 'document.compatMode' configuration property settings."}
function Ub(){var a=['\\u0000','\\u0001','\\u0002','\\u0003','\\u0004','\\u0005','\\u0006','\\u0007','\\b','\\t','\\n','\\u000B','\\f','\\r','\\u000E','\\u000F','\\u0010','\\u0011','\\u0012','\\u0013','\\u0014','\\u0015','\\u0016','\\u0017','\\u0018','\\u0019','\\u001A','\\u001B','\\u001C','\\u001D','\\u001E','\\u001F'];a[34]='\\"';a[92]='\\\\';a[173]='\\u00ad';a[1536]='\\u0600';a[1537]='\\u0601';a[1538]='\\u0602';a[1539]='\\u0603';a[1757]='\\u06dd';a[1807]='\\u070f';a[6068]='\\u17b4';a[6069]='\\u17b5';a[8203]='\\u200b';a[8204]='\\u200c';a[8205]='\\u200d';a[8206]='\\u200e';a[8207]='\\u200f';a[8232]='\\u2028';a[8233]='\\u2029';a[8234]='\\u202a';a[8235]='\\u202b';a[8236]='\\u202c';a[8237]='\\u202d';a[8238]='\\u202e';a[8288]='\\u2060';a[8289]='\\u2061';a[8290]='\\u2062';a[8291]='\\u2063';a[8292]='\\u2064';a[8298]='\\u206a';a[8299]='\\u206b';a[8300]='\\u206c';a[8301]='\\u206d';a[8302]='\\u206e';a[8303]='\\u206f';a[65279]='\\ufeff';a[65529]='\\ufff9';a[65530]='\\ufffa';a[65531]='\\ufffb';return a}
function zy(a,b,c,d,e,f,g,h,i,j,k){var l;l=new AA;Rc(l.a,"<section id='todoapp'> <header id='header'> <h1>todos<\/h1> <span id='");zA(l,En(a));Rc(l.a,"'><\/span> <\/header> <section id='");zA(l,En(b));Rc(l.a,"'> <input id='");zA(l,En(c));Rc(l.a,"' type='checkbox'> <label for='toggle-all'>Mark all as complete<\/label> <div id='todo-list'> <span id='");zA(l,En(d));Rc(l.a,"'><\/span> <\/div> <\/section> <footer id='");zA(l,En(e));Rc(l.a,"'> <span id='todo-count'> <strong class='number' id='");zA(l,En(f));Rc(l.a,"'><\/strong> <span class='word' id='");zA(l,En(g));Rc(l.a,"'><\/span> left <\/span> <ul id='filters'> <li> <span id='");zA(l,En(h));Rc(l.a,IG);zA(l,En(i));Rc(l.a,IG);zA(l,En(j));Rc(l.a,"'><\/span> <\/li> <\/ul> <span id='");zA(l,En(k));Rc(l.a,"'><\/span> <\/footer> <\/section> <footer id='info'> <p>Double-click to edit a todo<\/p> <p>Created by <a href='http://www.scottlogic.co.uk/blog/colin/'>Colin Eberhardt<\/a><\/p> <p>Part of <a href='http://todomvc.com'>TodoMVC<\/a><\/p> <\/footer>");return new ln(l.a.a)}
function od(a){var b;b=ud(a,'script');b.text='function __gwt_initWindowCloseHandler(beforeunload, unload) {\n  var wnd = window\n  , oldOnBeforeUnload = wnd.onbeforeunload\n  , oldOnUnload = wnd.onunload;\n  \n  wnd.onbeforeunload = function(evt) {\n    var ret, oldRet;\n    try {\n      ret = beforeunload();\n    } finally {\n      oldRet = oldOnBeforeUnload && oldOnBeforeUnload(evt);\n    }\n    // Avoid returning null as IE6 will coerce it into a string.\n    // Ensure that "" gets returned properly.\n    if (ret != null) {\n      return ret;\n    }\n    if (oldRet != null) {\n      return oldRet;\n    }\n    // returns undefined.\n  };\n  \n  wnd.onunload = function(evt) {\n    try {\n      unload();\n    } finally {\n      oldOnUnload && oldOnUnload(evt);\n      wnd.onresize = null;\n      wnd.onscroll = null;\n      wnd.onbeforeunload = null;\n      wnd.onunload = null;\n    }\n  };\n  \n  // Remove the reference once we\'ve initialize the handler\n  wnd.__gwt_initWindowCloseHandler = undefined;\n}\n';return b}
function Gs(){$wnd.__gwt_globalEventArray==null&&($wnd.__gwt_globalEventArray=new Array);$wnd.__gwt_globalEventArray[$wnd.__gwt_globalEventArray.length]=iF(function(){return Ur($wnd.event)});var e=iF(function(){var a=td;td=this;if($wnd.event.returnValue==null){$wnd.event.returnValue=true;if(!Js()){td=a;return}}var b=us;var c,d=this;while(d&&!(c=b(d))){d=d.parentElement}c&&Tr($wnd.event,d,c);td=a});var f=iF(function(){var a=$doc.createEventObject();$wnd.event.returnValue==null&&$wnd.event.srcElement.fireEvent&&$wnd.event.srcElement.fireEvent(lG,a);if(this.__eventBits&2){e.call(this)}else if($wnd.event.returnValue==null){$wnd.event.returnValue=true;Js()}});var g=iF(function(){this.__gwtLastUnhandledEvent=$wnd.event.type;e.call(this)});var h=$moduleName.replace(/\./g,'_');$wnd['__gwt_dispatchEvent_'+h]=e;Cs=(new Function(mG,'return function() { w.__gwt_dispatchEvent_'+h+'.call(this) }'))($wnd);$wnd['__gwt_dispatchDblClickEvent_'+h]=f;Bs=(new Function(mG,'return function() { w.__gwt_dispatchDblClickEvent_'+h+nG))($wnd);$wnd['__gwt_dispatchUnhandledEvent_'+h]=g;Es=(new Function(mG,oG+h+nG))($wnd);Ds=(new Function(mG,oG+h+'.call(w.event.srcElement)}'))($wnd);var i=iF(function(){e.call($doc.body)});var j=iF(function(){f.call($doc.body)});$doc.body.attachEvent(lG,i);$doc.body.attachEvent('onmousedown',i);$doc.body.attachEvent('onmouseup',i);$doc.body.attachEvent('onmousemove',i);$doc.body.attachEvent('onmousewheel',i);$doc.body.attachEvent('onkeydown',i);$doc.body.attachEvent('onkeypress',i);$doc.body.attachEvent('onkeyup',i);$doc.body.attachEvent('onfocus',i);$doc.body.attachEvent('onblur',i);$doc.body.attachEvent('ondblclick',j);$doc.body.attachEvent('oncontextmenu',i)}
function Tq(b,c){var d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,A,B,C,D,F,G,H,I,J,K,L,M,N,O,P,Q,R,S;b.f=null;if(b.b){return false}b.b=true;if(!b.e){b.b=false;b.g=0;return false}++b.g;if(b.g>10){b.b=false;b.g=0;throw new zz('A possible infinite loop has been detected in a Cell Widget. This usually happens when your SelectionModel triggers a SelectionChangeEvent when SelectionModel.isSelection() is called, which causes the table to redraw continuously.')}t=b.i;l=b.e;b.i=b.e;b.e=null;!c&&(c=[]);B=l.g;A=l.f;w=B+A;O=l.k.b;l.d=Oz(0,Pz(l.d,O-1));if((zr(),xr)==b.d){l.d=0;l.e=null}else if(l.a){l.e=O>0?ir(l,l.d):null}else if(l.e!=null){e=Mq(l,l.e,l.d);if(e>=0){l.d=e;l.e=O>0?ir(l,l.d):null}else{l.d=0;l.e=null}}try{if(wr==b.d&&false){u=t.o;m=O>0?ir(l,l.d):null;if(m!=null){v=u!=null&&null.Kb();n=m!=null&&null.Kb();if(Ib(m,u)){n||(l.o=null)}else{v&&null.Kb();l.o=m;m!=null&&!n&&null.Kb()}}}}catch(a){a=um(a);if(Zh(a,55)){f=a;b.b=false;b.g=0;throw tm(f)}else throw tm(a)}h=l.a||t.d!=l.d||t.e==null&&l.e!=null;o=new uE;try{for(g=B;g<B+O;g++){OC(l.k,g-B);Q=sE(t.n,Lz(g));Q&&Lb(c,g)}}catch(a){a=um(a);if(Zh(a,55)){f=a;b.b=false;b.g=0;throw tm(f)}else throw tm(a)}L=false;for(N=new jC(l.c);N.b<N.d.wb();){M=Xh(hC(N),35);P=M.b;i=M.a;i==0&&(L=true);for(g=P;g<P+i;g++){Lb(c,g)}}if(c.length>0&&h){Lb(c,t.d);Lb(c,l.d)}if(b.e){b.b=false;b.e.o=l.o;b.e.n.Cb(o);h&&(b.e.a=true);l.b&&(b.e.b=true);Lb(c,t.d);Lb(c,l.d);if(Tq(b,c)){return true}}j=Kq(c,B,w);F=j.b>0?(VB(0,j.b),Xh(j.a[0],35)):null;G=j.b>1?(VB(1,j.b),Xh(j.a[1],35)):null;J=0;for(D=new jC(j);D.b<D.d.wb();){C=Xh(hC(D),35);J+=C.a}q=t.g;p=t.f;r=t.k.b;H=false;B!=q?(H=true):O<r?(H=true):!G&&!!F&&F.b==B&&(J>=r||J>p)?(H=true):J>=5&&J>0.3*r?(H=true):L&&r==0&&(H=true);R=(!b.e?b.i:b.e).k.b;S=(!b.e?b.i:b.e).j?Pz((!b.e?b.i:b.e).f,(!b.e?b.i:b.e).i-(!b.e?b.i:b.e).g):(!b.e?b.i:b.e).f;R>=S?Bp(b.j,(Nr(),Kr)):R==0?Bp(b.j,(Nr(),Lr)):Bp(b.j,(Nr(),Mr));try{if(H){new rn;xp(b.j,l.k,l.b);zp(b.j)}else if(F){d=F.b;I=d-B;new rn;K=new sC(l.k,I,I+F.a);yp(b.j,K,I,l.b);if(G){d=G.b;I=d-B;new rn;K=new sC(l.k,I,I+G.a);yp(b.j,K,I,l.b)}zp(b.j)}else if(h){s=t.d;s>=0&&s<O&&Ap(b.j,s,false,false);k=l.d;k>=0&&k<O&&Ap(b.j,k,true,l.b)}}catch(a){a=um(a);if(Zh(a,50)){f=a;throw new yb(f)}else throw tm(a)}finally{b.b=false}Tq(b,null);return true}
function Gn(){this.a='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFIAAAAaCAYAAAAkJwuaAAAHt0lEQVR42u1SWVeURxD9fiqLuOFugp5ojjsuzMBIEDXHFSOKRIHI9kNmBgYERkHEhWQcQB47XWtX94xPyaMP91RX1a1bt76ZrG961/XNBPROf3N9syEvzMZ1jDO7jZhtfAMX52fNe4bnjY5oCjetx7rfIl+pXgHfpi+a3/M9sxvdlUboRd/A9MO3+uYySPLTO764wxHyUEv7eRbIa27n4mgRa3/Tt61Zrd7v1prvEG8Bu4nP5l56k3vi+3cbZuKdYW+Wn9rGJDdFwNwjN+nzyW2G9KS2RXFqSznam5IcdO17h3Lo465t5eent7QGnLzujd8KvxdnJsW7eOZcdCd3ON+Kenn0tMX7hC+3hzzcs0Mz0zsufK/taD678deWE/S85ncStc7vHunB+/V2qL+OZ+2cziO3Hmr+DRrxjnrQg9oEoB68mF7k2XqYYE+TW9Gc3qRekv5EvcGz6Ik+cet0B+/Jro1/ddfG6+7a2Fd3dbzmro4BfG0CcgJyJoBTw3jdA7gQsT5RYx7nfv46zGOsoxZwcNZzUB+44zXdQxzag/kYY7zOs7xvvB57klmuiXfSD36CvszVlX+dta5P1I1GTW+jnaQFPb1rvK6a2ZWX/zhAN+PKq5BDvPyy5rrHoO7jq6++ZnPiIP8VzNRofizUr1iO/yG6hQtvbwj7jMvIYbykfd3pXtSuEUCHfZCn4EU0YY/W/b7ul7RHvHVHHmuhZ/Ox+I7L9nuNkW528c+/HeASQ94XRzfNO/QuvKA61GyfdDZDfTTWDJx0T8ClRM/2I51R2nVJdtr3qKlFvKAf8s34vlG6O3DiWXtjWs/OPf/izo8APjt6QxSE/PzIZoD/mOe5h32OCJmF94vPxB2hSDrw/oI6oK/cEbtzE2vnrDZrnROvii+860vQey75Z90pPNl3AfojPDMSe470Rqzm58B9Hr4LxOzs8Ib79dlHd/YpwL+HP3lw7t9Qk/rZpwTo//qMefCG3jDNgx7MYp915Q2RND+aHfQ+gzs+sk7wgH6esY9kBv2g30/sgeIZ2Tn8KdyA7w2e4ZuHrR/pi3/7DT6qBt3CO58xz89lv/zxwUV4AnGDcxOfbHBu37Zn+Jp/CPnQh+/MmRrsHvrQqIWwPesN6nZ/sju9I+pvNJ95Ym568r25eEd2+vG663q05iCe8vHUo/fu1OP3PodoahAfvw/QmXXiD9GMBXKGZIbnI33hroca6q0HP6LNOKX8ddXA95B49L0h63eNdsgs6qyrjvod4nutrvX/iHDafgP0SLzs5werruvBmoNI8O+HnD9cDW/be8i9ByF2ab4WuDrXRCvdYfUeyvya0VnDHxz2dKlHyJtoPmjij+fphtRP7FVvifyYHU362Yl779xJhr7vx2/bOyHv+6s6d/LeqrM6kFtu1MM54Nv5dw3z0v/p/qrRWdW9J4y3Ru3GnannhrsjzmoTT83uDsiO//7WHUOsYDyuWHHUq5pawDGN0K/ifGN8m2iI5kqkGzSqTfYEvWMY35pceFXjZ8XMV6P+MVOLb61GIB8riZ9q5DXdmR25u+KO3Fl2RyF6HGUcubvsUcUevEO9yvwq5XeYyzziVpFHMxKXmVtVrbDTzi4bP5QrF3esqJ76kf3sK3jmaG6wUd/Jjek+ywt3xPzs0O0ld/j2sseSOzS4RBGxrPnhO1SLOIPEOaxYatDAOdFgPYFy73CPIfvCrPEBGIz3HG7iy9ZTNOvbWoO/iLNsbo/7WefAkjs48MbDx1tv8N3pYydE7S26zkGOt0IfZjpvEUf6pLFI87eoTjNmtgFL+qb9S6zdfDbsXWRPcBTvh96g+It9H5R52WfvEx8DokteSPeN8lQD30v6zg70LzrEbws+VtyBAckJ+/sXqOb78MYcepY3wLM+3w86zIX8YKS3EGsjt8KaMAMaC2RSdjP29y+qjwP9wQvpV0iLtaGGWrITovhGVPQGuU/84g2gx98ixAXaIVzR5Vq272bF7bu54Ch6wADEgtTn/Zujx94CcahWCX2o3ZS6iczBOdlxM5n12FuY93tlXyXe15AzV/b2Bz2sS834JlR4hjzs1zl7Z/I9NLee502P3tnevorr6Jtzez06+sAovQnzoe7RwYCj4SCcK8xznMMYtLhWEP689mhHhXXNnNeUumgjZKYwr57En3juKMzpXOSrr2JusHeae4xv2iP3JP1C4GjO3yHb01t2e3rn3J48oQPeHu15rktPOfNab5e65Zh6u9eWt+jG3HLzmDdIZtqtT9vvDXvakxrw2u18bznqx3eU49t7E/9NdgKytlwJhdryJRRoYyGKvp7jCDXmtkvPz1C9zLVy1Fee7MiBru0DShrbolo54ZWNz7moT/vjOu0qNfHEu5Jbgl56j62V1FuqncGHaPWk1p6SRxEXUIR6CQdac0X+YEWqCfiDIz9f5FjmXhF1IdIHL9EO0OgpkT7zW3NsLldkfpk5MiMeJC/r7jbxxse28gfEOnsUDZzP0w1yI91S1D9FvK+sd6AfuU3vK+l9mRzWeqOoH1MPjmpF1yJ5rqQf1H4c5OeKmhNfNIJB1WQd4bXYfTnObxgt2cdaLT3F2K/Z0ZJ4aeX5lh6pWz/El5nYR7JLZsUb9zM19gP/CT8+5P+EfwFEPZjKzXkk0QAAAABJRU5ErkJggg=='}
var mF='',rF=' ',pF='"',qG='#',rG='%23',MF='&',PF="'",IG="'><\/span> <\/li> <li> <span id='",nF='(',IF=')',CF=',',FF=', ',BG=', Size: ',nG='.call(this)}',wF='/active',xF='/completed',KF='0',vG='0px',tG='100%',qF=':',jF=': ',tF='<',KG='=',OF='>',jG='CSS1Compat',HF='Error parsing JSON: ',bH='EventBus',JG='For input string: "',_F='GMY2FQLBB',HG='GMY2FQLEI',CG='INPUT',AG='Index: ',cH='SimpleEventBus',lF='String',UG='UmbrellaException',BF='[',YG='[Lcom.google.gwt.user.cellview.client.',$G='[Lcom.google.gwt.user.client.ui.',OG='[Ljava.lang.',DF=']',bG='__gwtCellBasedWidgetImplDispatchingFocus',SF='aria-hidden',YF='blur',aG='change',uF='click',jH='com.google.gwt.animation.client.',eH='com.google.gwt.cell.client.',NG='com.google.gwt.core.client.',VG='com.google.gwt.core.client.impl.',kH='com.google.gwt.dom.client.',iH='com.google.gwt.event.dom.client.',XG='com.google.gwt.event.logical.shared.',SG='com.google.gwt.event.shared.',_G='com.google.gwt.i18n.client.',gH='com.google.gwt.json.client.',lH='com.google.gwt.safehtml.shared.',fH='com.google.gwt.storage.client.',nH='com.google.gwt.text.shared.testing.',mH='com.google.gwt.uibinder.client.',WG='com.google.gwt.user.cellview.client.',aH='com.google.gwt.user.client.',hH='com.google.gwt.user.client.impl.',PG='com.google.gwt.user.client.ui.',ZG='com.google.gwt.view.client.',RG='com.google.web.bindery.event.shared.',QG='com.todo.client.',TG='com.todo.client.events.',FG='complete',DG='completed',kG='dblclick',yF='dir',WF='display',sF='div',dG='error',XF='focus',LG='fromIndex: ',oF='function',NF='g',uG='height',LF='html is null',JF='ie8',fG='input',MG='java.lang.',dH='java.util.',ZF='keydown',vF='keyup',cG='load',AF='ltr',$F='mousedown',UF='mouseout',hG='mouseup',iG='mousewheel',zG='msie',RF='none',kF='null',lG='onclick',pG='onload',wG='overflow',oG='return function() { w.__gwt_dispatchUnhandledEvent_',zF='rtl',eG='select',GG='selected',VF='tabIndex',EG='task',gG='textarea',QF='todo-gwt',TF='true',yG='value',xG='visible',mG='w',sG='width',EF='{',GF='}';var _,bn={},QE={44:1,51:1,55:1,57:1},RE={3:1,4:1,44:1,47:1,49:1},OE={},TE={38:1,44:1,51:1,55:1,57:1},aF={31:1,44:1,47:1,49:1},fF={63:1},VE={19:1,44:1},UE={7:1,11:1},PE={44:1},XE={9:1,12:1,24:1,25:1,27:1,28:1,30:1,32:1},ZE={11:1,33:1},_E={9:1,12:1,24:1,25:1,26:1,28:1,29:1,30:1,32:1},cF={37:1},WE={9:1,12:1,24:1,25:1,28:1,30:1,32:1},dF={46:1},SE={12:1},YE={9:1,12:1,24:1,25:1,27:1,28:1,30:1,32:1,34:1},hF={44:1,60:1},gF={62:1},eF={61:1},$E={9:1,12:1,24:1,25:1,26:1,28:1,30:1,32:1},bF={60:1};cn(1,-1,OE,V);_.eQ=function W(a){return this===a};_.gC=function X(){return this.cZ};_.hC=function Y(){return ec(this)};_.tS=function Z(){return this.cZ.c+'@'+Jz(this.hC())};_.toString=function(){return this.tS()};_.tM=LE;cn(3,1,{});_.e=false;_.f=false;_.g=false;cn(4,1,{});cn(5,4,{});cn(6,5,{},fb);cn(7,1,{});cn(8,1,{},jb);_.a=0;cn(9,1,{},lb);_.a=0;cn(14,1,{44:1,57:1});_.A=function tb(){return this.e};_.tS=function ub(){return sb(this)};cn(13,14,{44:1,51:1,57:1});cn(12,13,QE,wb,yb);cn(11,12,{2:1,44:1,51:1,55:1,57:1},Cb);_.A=function Fb(){Bb(this);return this.c};_.B=function Gb(){return this.b===zb?null:this.b};var zb;var Ob,Pb=false;cn(21,1,{});var Wb=0,Xb=0,Yb=0,Zb=-1;cn(23,21,{},vc);_.d=false;_.i=false;var lc;cn(24,1,{},Bc);_.C=function Cc(){this.a.d=true;pc(this.a);this.a.d=false;return this.a.i=qc(this.a)};cn(25,1,{},Ec);_.C=function Fc(){this.a.d&&zc(this.a.e,1);return this.a.i};cn(28,1,{},Mc);_.F=function Nc(a){return Gc(a)};cn(29,1,{});cn(30,29,{},Sc);_.a=mF;var td;cn(46,1,{44:1,47:1,49:1});_.eQ=function Jd(a){return this===a};_.hC=function Kd(){return ec(this)};_.tS=function Ld(){return this.b};_.c=0;cn(45,46,RE);var Md,Nd,Od,Pd,Qd;cn(47,45,RE,Vd);cn(48,45,RE,Xd);cn(49,45,RE,Zd);cn(50,45,RE,_d);var ae,be=false,ce,de,ee;cn(53,1,{},ke);_.D=function le(){(fe(),be)&&ge()};var ne;cn(61,1,{});_.tS=function Be(){return 'An event type'};cn(60,61,{});_.g=false;cn(59,60,{});_.H=function He(){return this.I()};var De;cn(58,59,{});cn(57,58,{});cn(56,57,{},Ke);_.G=function Le(a){qx(Xh(Xh(a,5),41).a.a)};_.I=function Me(){return Ie};var Ie;cn(64,1,{});_.hC=function Re(){return this.c};_.tS=function Se(){return 'Event type'};_.c=0;var Qe=0;cn(63,64,{},Te);cn(62,63,{6:1},Ue);cn(66,59,{});cn(65,66,{});cn(67,65,{},$e);_.G=function _e(a){Xh(a,7).J(this)};_.I=function af(){return Ye};var Ye;cn(68,1,{},ef);cn(70,60,{},hf);_.G=function jf(a){Xh(a,8);mu()};_.H=function lf(){return gf};var gf;cn(71,60,{},pf);_.G=function qf(a){of(this,Xh(a,10))};_.H=function sf(){return nf};var nf;cn(73,1,{});cn(72,73,SE);cn(74,1,SE,zf);cn(76,73,{},Lf);_.K=function Nf(a,b,c){this.b>0?Cf(this,new Ww(this,a,c)):Gf(this,a,c)};_.b=0;_.c=false;cn(75,76,{},Of);_.K=function Pf(a,b,c){this.b>0?Cf(this,new Ww(this,a,c)):Gf(this,a,c)};cn(77,1,{},Rf);cn(78,72,SE,Uf);cn(80,12,TE,Xf);cn(79,80,TE,$f);cn(81,1,UE,ag);_.J=function bg(a){};cn(83,46,{13:1,44:1,47:1,49:1},kg);var fg,gg,hg,ig;cn(85,1,{});_.M=function og(){return null};_.N=function pg(){return null};_.O=function qg(){return null};_.P=function rg(){return null};cn(84,85,{14:1},vg,wg);_.eQ=function xg(a){if(!Zh(a,14)){return false}return this.a==Xh(a,14).a};_.L=function yg(){return Cg};_.hC=function zg(){return ec(this.a)};_.M=function Ag(){return this};_.tS=function Bg(){return ug(this)};cn(86,85,{},Hg);_.L=function Ig(){return Lg};_.N=function Jg(){return this};_.tS=function Kg(){return Zy(),mF+this.a};_.a=false;var Eg,Fg;cn(87,12,QE,Ng,Og);cn(88,85,{},Sg);_.L=function Tg(){return Vg};_.tS=function Ug(){return kF};var Qg;cn(89,85,{15:1},Xg);_.eQ=function Yg(a){if(!Zh(a,15)){return false}return this.a==Xh(a,15).a};_.L=function Zg(){return ah};_.hC=function $g(){return bi((new rz(this.a)).a)};_.tS=function _g(){return this.a+mF};_.a=0;cn(90,85,{16:1},ih,jh);_.eQ=function kh(a){if(!Zh(a,16)){return false}return this.a==Xh(a,16).a};_.L=function lh(){return ph};_.hC=function mh(){return ec(this.a)};_.O=function nh(){return this};_.tS=function oh(){var a,b,c,d,e,f;f=new vA;Rc(f.a,EF);a=true;e=dh(this,Nh(qm,PE,1,0,0));for(c=0,d=e.length;c<d;++c){b=e[c];a?(a=false):(Rc(f.a,FF),f);uA(f,Tb(b));Rc(f.a,qF);tA(f,eh(this,b))}Rc(f.a,GF);return f.a.a};var qh;cn(92,85,{17:1},Ch);_.eQ=function Dh(a){if(!Zh(a,17)){return false}return aA(this.a,Xh(a,17).a)};_.L=function Eh(){return Ih};_.hC=function Fh(){return qA(this.a)};_.P=function Gh(){return this};_.tS=function Hh(){return Tb(this.a)};cn(93,1,{},Jh);_.qI=0;var Qh,Rh;var vm;var Lm;var Xm,Ym,Zm,$m;cn(106,1,{},jn);_.a=0;_.b=0;_.c=0;cn(107,1,VE,ln);_.Q=function mn(){return this.a};_.eQ=function nn(a){if(!Zh(a,19)){return false}return aA(this.a,Xh(a,19).Q())};_.hC=function on(){return qA(this.a)};cn(108,1,{},rn);cn(109,1,VE,tn);_.Q=function un(){return this.a};_.eQ=function vn(a){if(!Zh(a,19)){return false}return aA(this.a,Xh(a,19).Q())};_.hC=function wn(){return qA(this.a)};_.tS=function xn(){return 'safe: "'+this.a+pF};var yn,zn,An,Bn,Cn;cn(111,1,{20:1,21:1},Gn);_.eQ=function Hn(a){if(!Zh(a,20)){return false}return aA(this.a,Xh(Xh(a,20),21).a)};_.hC=function In(){return qA(this.a)};cn(113,1,{},On);var Ln,Mn;cn(114,1,{},Rn);_.a=false;cn(117,1,{});cn(118,1,{},Xn);var Wn;cn(119,117,{},$n);var Zn;cn(120,1,{},bo);var co;cn(122,1,{},io);cn(126,1,{25:1,30:1});_.R=function ro(){throw new EA};_.tS=function uo(){if(!this.u){return '(null handle)'}return (Rr(),this.u).outerHTML};cn(125,126,WE);_.S=function Do(){};_.T=function Eo(){};_.U=function Fo(){return this.q};_.V=function Go(){yo(this)};_.W=function Ho(a){zo(this,a)};_.X=function Io(){if(!this.U()){throw new zz("Should only call onDetach when the widget is attached to the browser's document")}try{this.Z()}finally{try{this.T()}finally{Rr();ws(this.u,null);this.q=false}}};_.Y=function Jo(){};_.Z=function Ko(){};_.$=function Lo(a){Bo(this,a)};_.q=false;_.r=0;cn(124,125,XE);_.U=function Oo(){return No(this)};_.V=function Po(){if(this.r!=-1){Co(this.p,this.r);this.r=-1}this.p.V();Rr();ws(this.u,this)};_.W=function Qo(a){zo(this,a);this.p.W(a)};_.X=function Ro(){try{this.Z()}finally{this.p.X()}};_.R=function So(){po(this,(Rr(),this.p.R()));return this.u};cn(123,124,YE);_._=function hp(){return Rq(this.n)};_.W=function ip(a){var b,c,d,e;!Jp&&(Jp=new Yp);Up(Jp,this,a);if(this.j){return}b=a.srcElement;if(!md(b)){return}d=b;if(!Ad((Rr(),this.u),b)){return}zo(this,a);this.p.W(a);c=a.type;if(aA(XF,c)){this.i=true;lq(this)}else if(aA(YF,c)){this.i=false;e=iq(this);!!e&&dd(e,_F)}else aA(ZF,c)?(this.i=true):aA($F,c)&&(!Jp&&(Jp=new Yp),Tp(Jp,d))&&(this.i=true);kq(this,a)};_.Z=function jp(){this.i=false};_.ab=function mp(a,b){cp(this,a,b)};_.bb=function np(a,b){Yq(this.n,a,b)};_.i=false;_.j=false;_.o=0;var To;cn(127,125,WE,pp);cn(128,1,ZE,sp);_.cb=function tp(a){var b,c,d,e,f,g,h;d=a.f;b=a.f.type;if(aA(ZF,b)&&!a.d){switch(pd(d)){case 40:rp(this,Oq(this.a.n)+1);a.c=true;wd(a.f);return;case 38:rp(this,Oq(this.a.n)-1);a.c=true;wd(a.f);return;case 34:g=this.a.n.c;(rr(),or)==g?rp(this,Rq(this.a.n).a):qr==g&&rp(this,Oq(this.a.n)+30);a.c=true;wd(a.f);return;case 33:h=this.a.n.c;(rr(),or)==h?rp(this,-Rq(this.a.n).a):qr==h&&rp(this,Oq(this.a.n)-30);a.c=true;wd(a.f);return;case 36:rp(this,-Rq(this.a.n).b);a.c=true;wd(a.f);return;case 35:rp(this,Nq(this.a.n).i-1);a.c=true;wd(a.f);return;case 32:a.c=true;wd(a.f);return;}}else if(aA(uF,b)){e=a.a.a-Rq(this.a.n).b;f=a.f.srcElement;c=(!Jp&&(Jp=new Yp),Tp(Jp,f));_o(this.a,e,!c)}else if(aA(XF,b)){e=a.a.a-Rq(this.a.n).b;if(Oq(this.a.n)!=e){_o(this.a,e,false);return}}};cn(129,1,{},Cp);_.b=false;cn(130,1,{},Ep);_.D=function Fp(){var a;if(!oq(this.a.a)){a=iq(this.a.a);!!a&&ad(a)}};cn(131,71,{},Hp);cn(132,1,{});var Jp;cn(133,132,{},Yp);_.b=false;var Mp,Np,Op=false,Pp,Qp;cn(134,1,{},dq);_.D=function eq(){bq(this.a)};cn(135,123,YE,qq);_.S=function sq(){var b;try{this.f.V()}catch(a){a=um(a);if(Zh(a,57)){b=a;throw new nt(mD(b))}else throw tm(a)}};_.T=function tq(){var b;try{this.f.X()}catch(a){a=um(a);if(Zh(a,57)){b=a;throw new nt(mD(b))}else throw tm(a)}};_.b=false;var gq;cn(136,1,{},vq);_.D=function wq(){Zo(this.a)};cn(137,1,{},Aq);var yq,zq;cn(138,1,{},Dq);_.a=false;cn(142,1,{12:1,34:1},_q);_._=function ar(){return Rq(this)};_.ab=function br(a,b){Xq(this,a,b)};_.bb=function cr(a,b){Yq(this,a,b)};_.b=false;_.g=0;cn(143,1,{},fr);_.D=function gr(){this.a.f==this&&Tq(this.a,null)};cn(144,1,{},jr);_.d=0;_.e=null;_.f=0;_.g=0;_.i=0;_.j=false;_.o=null;_.p=false;cn(145,144,{},lr);_.a=false;_.b=false;cn(146,46,{22:1,44:1,47:1,49:1},sr);_.a=false;var nr,or,pr,qr;cn(147,46,{23:1,44:1,47:1,49:1},Ar);var vr,wr,xr,yr;cn(148,60,{},Fr);_.G=function Gr(a){ci(a);null.Kb()};_.H=function Hr(){return Dr};var Dr;cn(149,1,{},Jr);var Kr,Lr,Mr;var Or=null,Pr,Qr;var Yr;var as=false,bs;cn(156,60,{},ks);_.G=function ls(a){ci(a);null.Kb()};_.H=function ms(){return is};var is;cn(157,74,SE,os);cn(158,1,{});var qs=false;cn(159,1,{},ys);cn(161,158,{});var Bs,Cs,Ds,Es;cn(160,161,{},Ks);cn(162,1,SE,Rs);_.db=function Ss(a){return decodeURI(a.replace(rG,qG))};_.eb=function Ts(a){return Os(a)};_.fb=function Us(a){a=a==null?mF:a;if(!aA(a,Ms==null?mF:Ms)){Ms=a;rf(this,a)}};var Ms=mF;cn(167,125,$E);_.S=function Zs(){ot(this,(mt(),kt))};_.T=function $s(){ot(this,(mt(),lt))};cn(166,167,$E);_.hb=function et(){return new sv(this.b)};_.gb=function ft(a){return ct(this,a)};cn(165,166,$E);_.gb=function it(a){var b;b=ct(this,a);b&&ht((Rr(),a.u));return b};cn(168,79,TE,nt);var kt,lt;cn(169,1,{},qt);_.ib=function rt(a){a.V()};cn(170,1,{},tt);_.ib=function ut(a){a.X()};cn(173,125,WE);_.V=function zt(){var a;yo(this);a=(Rr(),this.u).tabIndex;-1==a&&kd(this.u,0)};cn(172,173,WE);cn(171,172,WE,Ct);cn(174,166,$E,Ht);_.gb=function It(a){var b,c;b=(Rr(),sd(a.u));c=ct(this,a);if(c){a.u.style[sG]=mF;a.u.style[uG]=mF;to(a.u,true);Yc(this.u,b);this.a==a&&(this.a=null)}return c};var Et;cn(175,3,{},Mt);_.a=null;_.b=null;_.c=false;_.d=null;cn(176,1,{},Pt);cn(177,166,$E,St);cn(178,125,WE,Xt);_.W=function Zt(a){var b,c,d,e,f,g;zo(this,a);if((Rr(),rs(a.type))==1&&(b=a.button|0,c=!!a.ctrlKey,d=!!a.shiftKey,e=b==4,f=b==2,wv?(g=d||c):(g=d),!g&&!e&&!f)){_r(this.c);wd(a)}};cn(180,165,_E);var gu,hu,iu;cn(181,1,{},qu);_.ib=function ru(a){a.U()&&a.X()};cn(182,1,{8:1,11:1},tu);cn(183,180,_E,vu);cn(184,167,$E,yu);_.hb=function Au(){return new Eu};_.gb=function Bu(a){return xu(this,a)};cn(185,1,{},Eu);_.jb=function Fu(){return false};_.kb=function Gu(){return Du()};_.lb=function Hu(){};cn(188,173,WE);_.W=function Nu(a){var b;b=(Rr(),rs(a.type));(b&896)!=0?zo(this,a):zo(this,a)};_.Y=function Ou(){};cn(187,188,WE);cn(186,187,WE);cn(189,46,aF);var Su,Tu,Uu,Vu,Wu;cn(190,189,aF,_u);cn(191,189,aF,bv);cn(192,189,aF,dv);cn(193,189,aF,fv);cn(194,1,{},nv);_.hb=function ov(){return new sv(this)};_.c=0;cn(195,1,{},sv);_.jb=function tv(){return this.b<this.c.c};_.kb=function uv(){return qv(this)};_.lb=function vv(){rv(this)};_.b=0;var wv=false;cn(200,1,{});_.c=-1;_.d=false;cn(201,1,{11:1,36:1},Gv);cn(202,60,{},Jv);_.G=function Kv(a){Xh(a,33).cb(this)};_.H=function Mv(){return Iv};_.c=false;_.d=false;_.e=false;var Iv;cn(203,1,ZE,Ov);_.cb=function Pv(a){var b;if(a.d||a.e){return}b=a.b;b.n;return};cn(204,200,{},Sv);cn(205,1,bF,_v,aw);_.mb=function bw(a){return Vv(this,a)};_.nb=function cw(){Wv(this)};_.ob=function dw(a){return this.f.ob(a)};_.eQ=function ew(a){return this.f.eQ(a)};_.pb=function fw(a){return Zv(this,a)};_.hC=function gw(){return this.f.hC()};_.qb=function hw(a){return this.f.qb(a)};_.rb=function iw(){return this.f.rb()};_.hb=function jw(){return new ww(this)};_.sb=function kw(){return new ww(this)};_.tb=function lw(a){return new xw(this,a)};_.ub=function mw(a){return $v(this,a)};_.vb=function nw(a){var b;b=this.f.qb(a);if(b==-1){return false}$v(this,b);return true};_.wb=function ow(){return this.f.wb()};_.xb=function pw(a,b){return new aw(this.n,this.f.xb(a,b),this,a)};_.yb=function qw(){return this.f.yb()};_.a=0;_.c=false;_.e=false;_.g=-2147483648;_.i=2147483647;_.j=false;_.k=0;cn(206,1,{},sw);_.D=function tw(){this.a.e=false;if(this.a.c){this.a.c=false;return}Yv(this.a)};cn(207,1,{},ww,xw);_.jb=function yw(){return this.a<this.c.f.wb()};_.zb=function zw(){return this.a>0};_.kb=function Aw(){if(this.a>=this.c.f.wb()){throw new JE}return Zv(this.c,this.b=this.a++)};_.Ab=function Bw(){if(this.a<=0){throw new JE}return Zv(this.c,this.b=--this.a)};_.lb=function Cw(){if(this.b<0){throw new zz('Cannot call add/remove more than once per call to next/previous.')}$v(this.c,this.b);this.a=this.b;this.b=-1};_.a=0;_.b=-1;cn(208,1,{35:1,44:1},Ew);_.eQ=function Fw(a){var b;if(!Zh(a,35)){return false}b=Xh(a,35);return this.b==b.b&&this.a==b.a};_.hC=function Gw(){return this.a*31^this.b};_.tS=function Hw(){return 'Range('+this.b+CF+this.a+IF};_.a=0;_.b=0;cn(209,60,{},Lw);_.G=function Mw(a){Kw(Xh(a,36))};_.H=function Ow(){return Jw};var Jw;cn(210,1,{},Rw);cn(211,1,cF,Tw);_.D=function Uw(){Ef(this.a,this.c,this.b)};cn(212,1,cF,Ww);_.D=function Xw(){Gf(this.a,this.c,this.b)};cn(214,186,WE,Zw);cn(215,7,{},gx);_.a=false;cn(217,1,{39:1},mx,nx);_.a=false;cn(218,1,{},zx);cn(219,1,{},Cx);cn(220,1,{11:1,43:1},Ex);cn(221,1,{11:1,42:1},Gx);cn(222,1,{10:1,11:1},Ix);cn(223,46,{40:1,44:1,47:1,49:1},Px);var Kx,Lx,Mx,Nx;cn(224,1,{},Sx);_.Bb=function Tx(a){return !a.a};cn(225,1,{},Vx);_.Bb=function Wx(a){return true};cn(226,1,{},Yx);_.Bb=function Zx(a){return a.a};cn(227,124,XE,fy);cn(228,1,{24:1},hy);_.W=function iy(a){Bx(this.b,!!this.a.o.checked)};cn(229,1,UE,ky);_.J=function ly(a){pd(a.a)==13&&px(this.a.a)};cn(230,1,{5:1,11:1,41:1},ny);cn(231,1,{},qy);cn(232,1,{},ty);var sy;cn(233,1,{},wy);_.a=false;cn(236,60,{});var By;cn(237,236,{},Iy);_.G=function Jy(a){Hy(this,Xh(a,42))};_.H=function Ky(){return Fy};var Fy;cn(238,236,{},Py);_.G=function Qy(a){Oy(this,Xh(a,43))};_.H=function Ry(){return My};var My;cn(239,12,QE,Ty);cn(240,12,QE,Vy);cn(241,1,{44:1,45:1,47:1},$y);_.eQ=function _y(a){return Zh(a,45)&&Xh(a,45).a==this.a};_.hC=function az(){return this.a?1231:1237};_.tS=function bz(){return this.a?TF:'false'};_.a=false;var Xy,Yy;cn(243,1,{},ez);_.tS=function lz(){return ((this.a&2)!=0?'interface ':(this.a&1)!=0?mF:'class ')+this.c};_.a=0;_.b=0;cn(244,12,QE,nz);cn(246,1,{44:1,54:1});
cn(245,246,{44:1,47:1,48:1,54:1},rz);_.eQ=function sz(a){return Zh(a,48)&&Xh(a,48).a==this.a};_.hC=function tz(){return bi(this.a)};_.tS=function uz(){return mF+this.a};_.a=0;cn(247,12,QE,wz);cn(248,12,QE,yz,zz);cn(249,12,{44:1,51:1,52:1,55:1,57:1},Bz,Cz);cn(250,246,{44:1,47:1,53:1,54:1},Ez);_.eQ=function Fz(a){return Zh(a,53)&&Xh(a,53).a==this.a};_.hC=function Gz(){return this.a};_.tS=function Kz(){return mF+this.a};_.a=0;var Mz;cn(253,12,QE,Rz,Sz);var Tz;cn(255,247,QE,Wz);cn(256,1,{44:1,56:1},Yz);_.tS=function Zz(){return this.a+'.'+this.c+'(Unknown Source'+(this.b>=0?qF+this.b:mF)+IF};_.b=0;_=String.prototype;_.cM={1:1,44:1,46:1,47:1};_.eQ=function jA(a){return aA(this,a)};_.hC=function kA(){return qA(this)};_.tS=_.toString;var lA,mA=0,nA;cn(258,1,dF,vA);_.tS=function wA(){return this.a.a};cn(259,1,dF,AA,BA);_.tS=function CA(){return this.a.a};cn(260,12,{44:1,51:1,55:1,57:1,58:1},EA,FA);cn(261,1,{});_.mb=function JA(a){throw new FA('Add not supported on this collection')};_.Cb=function KA(a){var b,c;c=a.hb();b=false;while(c.jb()){this.mb(c.kb())&&(b=true)}return b};_.ob=function LA(a){var b;b=HA(this.hb(),a);return !!b};_.rb=function MA(){return this.wb()==0};_.vb=function NA(a){var b;b=HA(this.hb(),a);if(b){b.lb();return true}else{return false}};_.yb=function OA(){return this.Db(Nh(om,PE,0,this.wb(),0))};_.Db=function PA(a){var b,c,d;d=this.wb();a.length<d&&(a=Lh(a,d));c=this.hb();for(b=0;b<d;++b){Ph(a,b,c.kb())}a.length>d&&Ph(a,d,null);return a};_.tS=function QA(){return IA(this)};cn(263,1,eF);_.eQ=function UA(a){var b,c,d,e,f;if(a===this){return true}if(!Zh(a,61)){return false}e=Xh(a,61);if(this.d!=e.d){return false}for(c=new AB((new sB(e)).a);gC(c.a);){b=c.b=Xh(hC(c.a),62);d=b.Fb();f=b.Gb();if(!(d==null?this.c:Zh(d,1)?dB(this,Xh(d,1)):cB(this,d,~~Jb(d)))){return false}if(!KE(f,d==null?this.b:Zh(d,1)?bB(this,Xh(d,1)):aB(this,d,~~Jb(d)))){return false}}return true};_.hC=function VA(){var a,b,c;c=0;for(b=new AB((new sB(this)).a);gC(b.a);){a=b.b=Xh(hC(b.a),62);c+=a.hC();c=~~c}return c};_.tS=function WA(){var a,b,c,d;d=EF;a=false;for(c=new AB((new sB(this)).a);gC(c.a);){b=c.b=Xh(hC(c.a),62);a?(d+=FF):(a=true);d+=mF+b.Fb();d+=KG;d+=mF+b.Gb()}return d+GF};cn(262,263,eF);_.Eb=function mB(a,b){return ai(a)===ai(b)||a!=null&&Ib(a,b)};_.c=false;_.d=0;cn(265,261,fF);_.eQ=function pB(a){var b,c,d;if(a===this){return true}if(!Zh(a,63)){return false}c=Xh(a,63);if(c.wb()!=this.wb()){return false}for(b=c.hb();b.jb();){d=b.kb();if(!this.ob(d)){return false}}return true};_.hC=function qB(){var a,b,c;a=0;for(b=this.hb();b.jb();){c=b.kb();if(c!=null){a+=Jb(c);a=~~a}}return a};cn(264,265,fF,sB);_.ob=function tB(a){return rB(this,a)};_.hb=function uB(){return new AB(this.a)};_.vb=function vB(a){var b;if(rB(this,a)){b=Xh(a,62).Fb();iB(this.a,b);return true}return false};_.wb=function wB(){return this.a.d};cn(266,1,{},AB);_.jb=function BB(){return gC(this.a)};_.kb=function CB(){return yB(this)};_.lb=function DB(){zB(this)};_.b=null;cn(268,1,gF);_.eQ=function GB(a){var b;if(Zh(a,62)){b=Xh(a,62);if(KE(this.Fb(),b.Fb())&&KE(this.Gb(),b.Gb())){return true}}return false};_.hC=function HB(){var a,b;a=0;b=0;this.Fb()!=null&&(a=Jb(this.Fb()));this.Gb()!=null&&(b=Jb(this.Gb()));return a^b};_.tS=function IB(){return this.Fb()+KG+this.Gb()};cn(267,268,gF,JB);_.Fb=function KB(){return null};_.Gb=function LB(){return this.a.b};_.Hb=function MB(a){return gB(this.a,a)};cn(269,268,gF,OB);_.Fb=function PB(){return this.a};_.Gb=function QB(){return bB(this.b,this.a)};_.Hb=function RB(a){return hB(this.b,this.a,a)};cn(270,261,bF);_.Ib=function TB(a,b){throw new FA('Add not supported on this list')};_.mb=function UB(a){this.Ib(this.wb(),a);return true};_.nb=function WB(){this.Jb(0,this.wb())};_.eQ=function XB(a){var b,c,d,e,f;if(a===this){return true}if(!Zh(a,60)){return false}f=Xh(a,60);if(this.wb()!=f.wb()){return false}d=new jC(this);e=f.hb();while(d.b<d.d.wb()){b=hC(d);c=e.kb();if(!(b==null?c==null:Ib(b,c))){return false}}return true};_.hC=function YB(){var a,b,c;b=1;a=new jC(this);while(a.b<a.d.wb()){c=hC(a);b=31*b+(c==null?0:Jb(c));b=~~b}return b};_.qb=function ZB(a){var b,c;for(b=0,c=this.wb();b<c;++b){if(a==null?this.pb(b)==null:Ib(a,this.pb(b))){return b}}return -1};_.hb=function _B(){return new jC(this)};_.sb=function aC(){return new oC(this,0)};_.tb=function bC(a){return new oC(this,a)};_.ub=function cC(a){throw new FA('Remove not supported on this list')};_.Jb=function dC(a,b){var c,d;d=new oC(this,a);for(c=a;c<b;++c){hC(d);iC(d)}};_.xb=function eC(a,b){return new sC(this,a,b)};cn(271,1,{},jC);_.jb=function kC(){return gC(this)};_.kb=function lC(){return hC(this)};_.lb=function mC(){iC(this)};_.b=0;_.c=-1;cn(272,271,{},oC);_.zb=function pC(){return this.b>0};_.Ab=function qC(){if(this.b<=0){throw new JE}return this.a.pb(this.c=--this.b)};cn(273,270,bF,sC);_.Ib=function tC(a,b){VB(a,this.b+1);++this.b;this.c.Ib(this.a+a,b)};_.pb=function uC(a){VB(a,this.b);return this.c.pb(this.a+a)};_.ub=function vC(a){var b;VB(a,this.b);b=this.c.ub(this.a+a);--this.b;return b};_.wb=function wC(){return this.b};_.a=0;_.b=0;cn(274,265,fF,zC);_.ob=function AC(a){return $A(this.a,a)};_.hb=function BC(){return yC(this)};_.wb=function CC(){return this.b.a.d};cn(275,1,{},FC);_.jb=function GC(){return gC(this.a.a)};_.kb=function HC(){return EC(this)};_.lb=function IC(){zB(this.a)};cn(276,270,hF,UC);_.Ib=function VC(a,b){KC(this,a,b)};_.mb=function WC(a){return LC(this,a)};_.Cb=function XC(a){return MC(this,a)};_.nb=function YC(){NC(this)};_.ob=function ZC(a){return PC(this,a,0)!=-1};_.pb=function $C(a){return OC(this,a)};_.qb=function _C(a){return PC(this,a,0)};_.rb=function aD(){return this.b==0};_.ub=function bD(a){return QC(this,a)};_.vb=function cD(a){return RC(this,a)};_.Jb=function dD(a,b){var c;VB(a,this.b+1);(b<a||b>this.b)&&$B(b,this.b);c=b-a;fD(this.a,a,c);this.b-=c};_.wb=function eD(){return this.b};_.yb=function iD(){return Kh(this.a,this.b)};_.Db=function jD(a){return TC(this,a)};_.b=0;var kD;cn(278,270,hF,pD);_.ob=function qD(a){return false};_.pb=function rD(a){throw new Bz};_.wb=function sD(){return 0};cn(279,1,{});_.mb=function wD(a){throw new EA};_.Cb=function xD(a){throw new EA};_.nb=function yD(){throw new EA};_.ob=function zD(a){return uD(this,a)};_.hb=function AD(){return new GD(this.b.hb())};_.vb=function BD(a){throw new EA};_.wb=function CD(){return this.b.wb()};_.yb=function DD(){return this.b.yb()};_.tS=function ED(){return this.b.tS()};cn(280,1,{},GD);_.jb=function HD(){return this.b.jb()};_.kb=function ID(){return this.b.kb()};_.lb=function JD(){throw new EA};cn(281,279,bF,LD);_.eQ=function MD(a){return this.a.eQ(a)};_.pb=function ND(a){return this.a.pb(a)};_.hC=function OD(){return this.a.hC()};_.qb=function PD(a){return this.a.qb(a)};_.rb=function QD(){return this.a.rb()};_.sb=function RD(){return new WD(this.a.tb(0))};_.tb=function SD(a){return new WD(this.a.tb(a))};_.ub=function TD(a){throw new EA};_.xb=function UD(a,b){return new LD(this.a.xb(a,b))};cn(282,280,{},WD);_.zb=function XD(){return this.a.zb()};_.Ab=function YD(){return this.a.Ab()};cn(283,281,bF,$D);cn(284,279,fF,aE);_.eQ=function bE(a){return this.b.eQ(a)};_.hC=function cE(){return this.b.hC()};cn(285,1,{44:1,47:1,59:1},eE);_.eQ=function fE(a){return Zh(a,59)&&Mm(Nm(this.a.getTime()),Nm(Xh(a,59).a.getTime()))};_.hC=function gE(){var a;a=Nm(this.a.getTime());return Um(Wm(a,Sm(a,32)))};_.tS=function iE(){var a,b,c;c=-this.a.getTimezoneOffset();a=(c>=0?'+':mF)+~~(c/60);b=(c<0?-c:c)%60<10?KF+(c<0?-c:c)%60:mF+(c<0?-c:c)%60;return (lE(),jE)[this.a.getDay()]+rF+kE[this.a.getMonth()]+rF+hE(this.a.getDate())+rF+hE(this.a.getHours())+qF+hE(this.a.getMinutes())+qF+hE(this.a.getSeconds())+' GMT'+a+b+rF+this.a.getFullYear()};var jE,kE;cn(287,262,{44:1,61:1},oE,pE);cn(288,265,{44:1,63:1},uE,vE);_.mb=function wE(a){return rE(this,a)};_.ob=function xE(a){return sE(this,a)};_.rb=function yE(){return this.a.d==0};_.hb=function zE(){return yC(TA(this.a))};_.vb=function AE(a){return tE(this,a)};_.wb=function BE(){return this.a.d};_.tS=function CE(){return IA(TA(this.a))};cn(289,268,gF,EE);_.Fb=function FE(){return this.a};_.Gb=function GE(){return this.b};_.Hb=function HE(a){var b;b=this.b;this.b=a;return b};cn(290,12,QE,JE);var iF=fc();var vl=gz(MG,'Object',1),mi=gz(NG,'Scheduler',21),li=gz(NG,'JavaScriptObject$',15),em=fz(mF,'[I',297),om=fz(OG,'Object;',295),Bl=gz(MG,'Throwable',14),nl=gz(MG,'Exception',13),wl=gz(MG,'RuntimeException',12),xl=gz(MG,'StackTraceElement',256),pm=fz(OG,'StackTraceElement;',298),hm=fz('[Lcom.google.gwt.lang.','LongLibBase$LongEmul;',299),aj=gz('com.google.gwt.lang.','SeedUtil',102),ml=gz(MG,'Enum',46),il=gz(MG,'Boolean',241),ul=gz(MG,'Number',246),dm=fz(mF,'[C',300),kl=gz(MG,'Class',243),ll=gz(MG,'Double',245),rl=gz(MG,'Integer',250),nm=fz(OG,'Integer;',301),Al=gz(MG,lF,2),qm=fz(OG,'String;',296),jl=gz(MG,'ClassCastException',244),ki=gz(NG,'JavaScriptException',11),zl=gz(MG,'StringBuilder',259),hl=gz(MG,'ArrayStoreException',240),kk=gz(PG,'UIObject',126),tk=gz(PG,'Widget',125),Wj=gz(PG,'Composite',124),cl=gz(QG,'ToDoView',227),Yk=gz(QG,'ToDoView$1',228),Zk=gz(QG,'ToDoView$2',229),$k=gz(QG,'ToDoView$3',230),Tk=gz(QG,'ToDoPresenter',218),Pk=gz(QG,'ToDoPresenter$1',219),Qk=gz(QG,'ToDoPresenter$2',220),Rk=gz(QG,'ToDoPresenter$3',221),Sk=gz(QG,'ToDoPresenter$4',222),Gk=gz(RG,'Event',61),Mi=gz(SG,'GwtEvent',60),dl=gz(TG,'ToDoEvent',236),fl=gz(TG,'ToDoUpdatedEvent',238),Ek=gz(RG,'Event$Type',64),Li=gz(SG,'GwtEvent$Type',63),el=gz(TG,'ToDoRemovedEvent',237),bk=gz(PG,'Panel',167),Vj=gz(PG,'ComplexPanel',166),Pj=gz(PG,'AbsolutePanel',165),Lk=gz(RG,UG,80),Ri=gz(SG,UG,79),Sj=gz(PG,'AttachDetachException',168),Qj=gz(PG,'AttachDetachException$1',169),Rj=gz(PG,'AttachDetachException$2',170),fk=gz(PG,'RootPanel',180),ek=gz(PG,'RootPanel$DefaultRootPanel',183),ck=gz(PG,'RootPanel$1',181),dk=gz(PG,'RootPanel$3',182),sl=gz(MG,'NullPointerException',253),ol=gz(MG,'IllegalArgumentException',247),gl=gz(MG,'ArithmeticException',239),si=gz(VG,'StringBufferImpl',29),sj=gz(WG,'AbstractHasData',123),oj=gz(WG,'AbstractHasData$DefaultKeyboardSelectionHandler',128),rj=gz(WG,'AbstractHasData$View',129),pj=gz(WG,'AbstractHasData$View$1',130),Ji=gz(XG,'ValueChangeEvent',71),qj=gz(WG,'AbstractHasData$View$2',131),nj=gz(WG,'AbstractHasData$1',127),Ej=hz(WG,'HasKeyboardPagingPolicy$KeyboardPagingPolicy',146,tr),im=fz(YG,'HasKeyboardPagingPolicy$KeyboardPagingPolicy;',302),Fj=hz(WG,'HasKeyboardSelectionPolicy$KeyboardSelectionPolicy',147,Br),jm=fz(YG,'HasKeyboardSelectionPolicy$KeyboardSelectionPolicy;',303),wk=gz(ZG,'CellPreviewEvent',202),Dj=gz(WG,'HasDataPresenter',142),Bj=gz(WG,'HasDataPresenter$DefaultState',144),Cj=gz(WG,'HasDataPresenter$PendingState',145),Aj=gz(WG,'HasDataPresenter$2',143),zj=gz(WG,'CellList',135),wj=gz(WG,'CellList$1',136),$j=gz(PG,'FocusWidget',173),Tj=gz(PG,'ButtonBase',172),Uj=gz(PG,'Button',171),qk=gz(PG,'ValueBoxBase',188),ik=gz(PG,'TextBoxBase',187),jk=gz(PG,'TextBox',186),Mk=gz(QG,'TextBoxWithPlaceholder',214),pk=hz(PG,'ValueBoxBase$TextAlignment',189,Zu),km=fz($G,'ValueBoxBase$TextAlignment;',304),lk=hz(PG,'ValueBoxBase$TextAlignment$1',190,null),mk=hz(PG,'ValueBoxBase$TextAlignment$2',191,null),nk=hz(PG,'ValueBoxBase$TextAlignment$3',192,null),ok=hz(PG,'ValueBoxBase$TextAlignment$4',193,null),Si=gz(_G,'AutoDirectionHandler',81),Ti=hz(_G,'HasDirection$Direction',83,lg),gm=fz('[Lcom.google.gwt.i18n.client.','HasDirection$Direction;',305),Ij=gz(aH,'Window$ClosingEvent',156),Oi=gz(SG,'HandlerManager',74),Jj=gz(aH,'Window$WindowHandlers',157),Fk=gz(RG,bH,73),Kk=gz(RG,cH,76),Ni=gz(SG,'HandlerManager$Bus',75),Hk=gz(RG,'SimpleEventBus$1',210),Ik=gz(RG,'SimpleEventBus$2',211),Jk=gz(RG,'SimpleEventBus$3',212),Xk=hz(QG,'ToDoRouting',223,Qx),mm=fz('[Lcom.todo.client.','ToDoRouting;',306),Vk=gz(QG,'ToDoRouting$MatchAll',225),Uk=gz(QG,'ToDoRouting$MatchActive',224),Wk=gz(QG,'ToDoRouting$MatchCompleted',226),vk=gz(ZG,'AbstractDataProvider',200),Bk=gz(ZG,'ListDataProvider',204),Ak=gz(ZG,'ListDataProvider$ListWrapper',205),zk=gz(ZG,'ListDataProvider$ListWrapper$WrappedListIterator',207),yk=gz(ZG,'ListDataProvider$ListWrapper$1',206),uk=gz(ZG,'AbstractDataProvider$1',201),Ck=gz(ZG,'RangeChangeEvent',209),Ki=gz(SG,bH,72),Ql=gz(dH,'AbstractMap',263),Il=gz(dH,'AbstractHashMap',262),_l=gz(dH,'HashMap',287),Dl=gz(dH,'AbstractCollection',261),Rl=gz(dH,'AbstractSet',265),Fl=gz(dH,'AbstractHashMap$EntrySet',264),El=gz(dH,'AbstractHashMap$EntrySetIterator',266),Pl=gz(dH,'AbstractMapEntry',268),Gl=gz(dH,'AbstractHashMap$MapEntryNull',267),Hl=gz(dH,'AbstractHashMap$MapEntryString',269),Ol=gz(dH,'AbstractMap$1',274),Nl=gz(dH,'AbstractMap$1$1',275),am=gz(dH,'HashSet',288),qi=gz(VG,'StackTraceCreator$Collector',28),ri=gz(VG,'StringBufferImplAppend',30),ji=gz(NG,'Duration',9),pi=gz(VG,'SchedulerImpl',23),ni=gz(VG,'SchedulerImpl$Flusher',24),oi=gz(VG,'SchedulerImpl$Rescuer',25),hi=gz(eH,'AbstractCell',7),Nk=gz(QG,'ToDoCell',215),ii=gz(eH,'Cell$Context',8),_k=gz(QG,'ToDoView_ToDoViewUiBinderImpl$Widgets',231),pl=gz(MG,'IllegalStateException',248),Ml=gz(dH,'AbstractList',270),Sl=gz(dH,'ArrayList',276),Jl=gz(dH,'AbstractList$IteratorImpl',271),Kl=gz(dH,'AbstractList$ListIteratorImpl',272),Ll=gz(dH,'AbstractList$SubList',273),hj=gz(fH,'Storage',113),gj=gz(fH,'Storage$StorageSupportDetector',114),_i=gz(gH,'JSONValue',85),Ui=gz(gH,'JSONArray',84),Zi=gz(gH,'JSONObject',90),$i=gz(gH,'JSONString',92),Vi=gz(gH,'JSONBoolean',86),Ok=gz(QG,'ToDoItem',217),Oj=gz(hH,'HistoryImpl',162),ak=gz(PG,'Hyperlink',178),Qi=gz(SG,cH,78),sk=gz(PG,'WidgetCollection',194),lm=fz($G,'Widget;',307),rk=gz(PG,'WidgetCollection$WidgetIterator',195),Nj=gz(hH,'DOMImpl',158),Kj=gz(hH,'DOMImpl$1',159),Mj=gz(hH,'DOMImplTrident',161),Lj=gz(hH,'DOMImplIE8',160),Bi=gz(iH,'DomEvent',59),Ei=gz(iH,'KeyEvent',66),Di=gz(iH,'KeyCodeEvent',65),Fi=gz(iH,'KeyUpEvent',67),Ai=gz(iH,'DomEvent$Type',62),Ci=gz(iH,'HumanInputEvent',58),Gi=gz(iH,'MouseEvent',57),zi=gz(iH,'ClickEvent',56),Cl=gz(MG,'UnsupportedOperationException',260),yl=gz(MG,'StringBuffer',258),yj=gz(WG,'CellList_Resources_default_InlineClientBundleGenerator',137),xj=gz(WG,'CellList_Resources_default_InlineClientBundleGenerator$1',138),Yj=gz(PG,'DeckPanel',174),gi=gz(jH,'Animation',3),Xj=gz(PG,'DeckPanel$SlideAnimation',175),fi=gz(jH,'AnimationScheduler',4),hk=gz(PG,'SimplePanel',184),gk=gz(PG,'SimplePanel$1',185),vj=gz(WG,'CellBasedWidgetImpl',132),Wi=gz(gH,'JSONException',87),xi=hz(kH,'Style$Display',45,Td),fm=fz('[Lcom.google.gwt.dom.client.','Style$Display;',308),ti=hz(kH,'Style$Display$1',47,null),ui=hz(kH,'Style$Display$2',48,null),vi=hz(kH,'Style$Display$3',49,null),wi=hz(kH,'Style$Display$4',50,null),bm=gz(dH,'MapEntryImpl',289),Ii=gz(XG,'CloseEvent',70),ql=gz(MG,'IndexOutOfBoundsException',249),Tl=gz(dH,'Collections$EmptyList',278),Vl=gz(dH,'Collections$UnmodifiableCollection',279),Xl=gz(dH,'Collections$UnmodifiableList',281),Yl=gz(dH,'Collections$UnmodifiableRandomAccessList',283),Zl=gz(dH,'Collections$UnmodifiableSet',284),Ul=gz(dH,'Collections$UnmodifiableCollectionIterator',280),Wl=gz(dH,'Collections$UnmodifiableListIterator',282),uj=gz(WG,'CellBasedWidgetImplTrident',133),tj=gz(WG,'CellBasedWidgetImplTrident$1',134),_j=gz(PG,'HTMLPanel',177),Yi=gz(gH,'JSONNumber',89),Xi=gz(gH,'JSONNull',88),Hi=gz(iH,'PrivateMap',68),Pi=gz(SG,'LegacyHandlerWrapper',77),Dk=gz(ZG,'Range',208),cm=gz(dH,'NoSuchElementException',290),xk=gz(ZG,'DefaultSelectionEventManager',203),ej=gz(lH,'SafeHtmlString',109),lj=gz(mH,'LazyDomElement',120),mj=gz(mH,'UiBinderUtil$TempAttachment',122),bl=gz(QG,'ToDoView_ToDoViewUiBinderImpl_GenBundle_default_InlineClientBundleGenerator',232),al=gz(QG,'ToDoView_ToDoViewUiBinderImpl_GenBundle_default_InlineClientBundleGenerator$1',233),cj=gz(lH,'OnlyToBeUsedInGeneratedCodeStringBlessedAsSafeHtml',107),dj=gz(lH,'SafeHtmlBuilder',108),yi=gz(kH,'StyleInjector$1',53),Zj=gz(PG,'DirectionalTextHelper',176),Hj=gz(WG,'LoadingStateChangeEvent',148),Gj=gz(WG,'LoadingStateChangeEvent$DefaultLoadingState',149),tl=gz(MG,'NumberFormatException',255),bj=gz('com.google.gwt.resources.client.impl.','ImageResourcePrototype',106),ij=gz('com.google.gwt.text.shared.','AbstractRenderer',117),kj=gz(nH,'PassthroughRenderer',119),jj=gz(nH,'PassthroughParser',118),fj=gz(lH,'SafeUriString',111),$l=gz(dH,'Date',285),ei=gz(jH,'AnimationSchedulerImpl',5),di=gz(jH,'AnimationSchedulerImplTimer',6);$stats && $stats({moduleName:'gwttodo',sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date()).getTime(),type:'moduleEvalEnd'});if (gwttodo && gwttodo.onScriptLoad)gwttodo.onScriptLoad(gwtOnLoad);})();