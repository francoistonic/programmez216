# README.md file
A User Guide is available in : $ACTION_ROOT/doc/SNAP_hls_sponge_UG_vxx.pdf
