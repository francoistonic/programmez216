All information are in the hls_memcopy/doc directory
