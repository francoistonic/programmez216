All information related to this example is in ~snap/actions/hls_hashjoin/doc
