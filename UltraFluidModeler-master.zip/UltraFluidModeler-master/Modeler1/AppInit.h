#pragma once
class CAppInit
{
public:
	CAppInit(void);
	~CAppInit(void);

public:
	void Init();
	void Uninit();
};

